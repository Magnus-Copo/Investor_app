/**
 * Mock Data Store - Replace with API calls for production
 */

// ============================================
// USER DATA - Multi-Account Support
// ============================================

// All user accounts for testing
export const userAccounts = {
    'USR001': {
        id: 'USR001',
        name: 'Lohith MS',
        email: 'lohith@investflow.com',
        role: 'investor',
        avatar: null,
        phone: '+91 98765 43210',
    },
    'USR002': {
        id: 'USR002',
        name: 'Rahul Sharma',
        email: 'rahul@investflow.com',
        role: 'investor',
        avatar: null,
        phone: '+91 98765 12345',
    },
    'USR003': {
        id: 'USR003',
        name: 'Priya Patel',
        email: 'priya@investflow.com',
        role: 'investor',
        avatar: null,
        phone: '+91 87654 32109',
    },
};

// Track current logged-in user (default to Lohith)
let currentUserId = 'USR001';

// Function to switch user (called from login)
export const setCurrentUserId = (userId) => {
    if (userAccounts[userId]) {
        currentUserId = userId;
    }
};

// Get current user object
export const getCurrentUser = () => userAccounts[currentUserId];

// Legacy export for backward compatibility
export const currentUser = userAccounts['USR001'];

// ============================================
// PORTFOLIO DATA (Client View)
// ============================================
export const portfolioSummary = {
    totalInvested: 2500000,
    currentValue: 2875000,
    returns: 375000,
    returnsPercent: 15.0,
    lastUpdated: '2026-01-13T10:30:00Z',
};

export const investments = [
    {
        id: 'INV001',
        projectId: 'PRJ001',
        name: 'Green Valley Real Estate',
        type: 'Real Estate',
        invested: 1500000,
        currentValue: 1725000,
        returns: 225000,
        returnsPercent: 15.0,
        status: 'active',
        progress: 65,
        startDate: '2025-06-15',
        expectedEndDate: '2027-06-15',
    },
    {
        id: 'INV002',
        projectId: 'PRJ002',
        name: 'TechStart Fund II',
        type: 'Venture Capital',
        invested: 1000000,
        currentValue: 1150000,
        returns: 150000,
        returnsPercent: 15.0,
        status: 'active',
        progress: 40,
        startDate: '2025-09-01',
        expectedEndDate: '2028-09-01',
    },
];

export const recentUpdates = [
    {
        id: 'UPD001',
        title: 'Q3 Report Available',
        description: 'Quarterly performance report is now available for download.',
        project: 'Green Valley Real Estate',
        timestamp: '2026-01-12T14:30:00Z',
        type: 'report',
        read: false,
    },
    {
        id: 'UPD002',
        title: 'Approval Required',
        description: 'Project modification requires your approval.',
        project: 'Green Valley Real Estate',
        timestamp: '2026-01-13T09:00:00Z',
        type: 'approval',
        read: false,
    },
];

// ============================================
// PROJECT MODIFICATION APPROVALS (Investor Side)
// ============================================
export const pendingModifications = [
    {
        id: 'MOD001',
        projectId: 'PRJ001',
        projectName: 'Green Valley Real Estate',
        title: 'Timeline Extension Request',
        description: 'Due to regulatory approvals taking longer than expected, we request extending the project completion by 3 months (from June 2027 to September 2027).',
        type: 'timeline',
        proposedBy: 'USR002', // Creator/Admin of PRJ001
        proposedAt: '2026-01-13T09:00:00Z',
        deadline: '2026-01-20T23:59:59Z',
        impact: {
            currentTimeline: 'June 2027',
            proposedTimeline: 'September 2027',
            returnImpact: 'No change in projected returns',
        },
        votes: {
            total: 4,
            approved: 2,
            rejected: 0,
            pending: 2,
        },
        // Privilege Chain: Individual investor approvals
        investorApprovals: {
            'USR001': { status: 'pending', votedAt: null },
            'USR002': { status: 'approved', votedAt: '2026-01-13T09:05:00Z' }, // Creator auto-approves
            'USR003': { status: 'approved', votedAt: '2026-01-13T14:30:00Z' },
            'USR004': { status: 'pending', votedAt: null },
        },
        creatorApproval: { status: 'approved', votedAt: '2026-01-13T09:05:00Z' },
        myVote: null, // null | 'approved' | 'rejected'
        status: 'pending', // 'pending' | 'approved' | 'rejected'
    },
    {
        id: 'MOD002',
        projectId: 'PRJ002',
        projectName: 'TechStart Fund II',
        title: 'Additional Capital Call',
        description: 'To capitalize on a promising Series B opportunity in our portfolio company, we are requesting an optional additional investment of up to ₹2L per investor.',
        type: 'capital',
        proposedBy: 'USR001', // Creator/Admin of PRJ002 (current user)
        proposedAt: '2026-01-11T14:00:00Z',
        deadline: '2026-01-18T23:59:59Z',
        impact: {
            minAmount: 0,
            maxAmount: 200000,
            expectedReturn: '+18% projected over 2 years',
        },
        votes: {
            total: 3,
            approved: 2,
            rejected: 0,
            pending: 1,
        },
        // Privilege Chain: Individual investor approvals
        investorApprovals: {
            'USR001': { status: 'approved', votedAt: '2026-01-11T14:05:00Z' }, // Creator auto-approves
            'USR002': { status: 'approved', votedAt: '2026-01-12T10:00:00Z' },
            'USR004': { status: 'pending', votedAt: null },
        },
        creatorApproval: { status: 'approved', votedAt: '2026-01-11T14:05:00Z' },
        myVote: 'approved',
        status: 'pending',
    },
];

// ============================================
// QUARTERLY REPORTS DATA
// ============================================
export const financialYears = [
    { id: 'FY2526', label: 'FY 2025-26', current: true },
    { id: 'FY2425', label: 'FY 2024-25', current: false },
];

export const quarterlyReports = [
    {
        id: 'RPT001',
        quarter: 'Q3',
        year: 'FY 2025-26',
        period: 'Oct - Dec 2025',
        status: 'available',
        publishedDate: '2026-01-10',
        fileSize: '2.4 MB',
        investments: ['Green Valley Real Estate', 'TechStart Fund II'],
        highlights: {
            portfolioGrowth: 15.0,
            totalReturns: 375000,
            dividendsReceived: 50000,
        },
    },
    {
        id: 'RPT002',
        quarter: 'Q2',
        year: 'FY 2025-26',
        period: 'Jul - Sep 2025',
        status: 'available',
        publishedDate: '2025-10-08',
        fileSize: '2.1 MB',
        investments: ['Green Valley Real Estate', 'TechStart Fund II'],
        highlights: {
            portfolioGrowth: 8.5,
            totalReturns: 212500,
            dividendsReceived: 25000,
        },
    },
    {
        id: 'RPT003',
        quarter: 'Q1',
        year: 'FY 2025-26',
        period: 'Apr - Jun 2025',
        status: 'available',
        publishedDate: '2025-07-12',
        fileSize: '1.9 MB',
        investments: ['Green Valley Real Estate'],
        highlights: {
            portfolioGrowth: 3.2,
            totalReturns: 80000,
            dividendsReceived: 0,
        },
    },
];

// ============================================
// ADMIN DATA
// ============================================
export const adminKPIs = {
    totalAUM: 125000000,
    activeProjects: 4,
    totalInvestors: 48,
    pendingApprovals: 2,
    monthlyGrowth: 2.3,
    lastUpdated: '2026-01-13T10:00:00Z',
};

export const projects = [
    {
        id: 'PRJ001',
        name: 'Green Valley Real Estate',
        type: 'Real Estate',
        status: 'active',
        investorCount: 12,
        raised: 25000000,
        target: 30000000,
        progress: 83,
        startDate: '2025-06-15',
        phase: 'Construction',
        // Privilege Chain Fields
        createdBy: 'USR002', // Rahul Sharma created this
        projectAdmins: ['USR002'], // Creator is admin
        projectInvestors: ['USR001', 'USR002', 'USR003', 'USR004'],
        privilegeChain: {
            modificationsRequireAllApproval: true,
            approvalThreshold: 100,
        },
    },
    {
        id: 'PRJ002',
        name: 'TechStart Fund II',
        type: 'Venture Capital',
        status: 'active',
        investorCount: 24,
        raised: 15000000,
        target: 20000000,
        progress: 75,
        startDate: '2025-09-01',
        phase: 'Investment',
        // Privilege Chain Fields
        createdBy: 'USR001', // Lohith created this (current user)
        projectAdmins: ['USR001'],
        projectInvestors: ['USR001', 'USR002', 'USR004'],
        privilegeChain: {
            modificationsRequireAllApproval: true,
            approvalThreshold: 100,
        },
    },
];

export const pendingApprovals = [
    {
        id: 'APR001',
        type: 'withdrawal',
        investor: { id: 'USR002', name: 'Rahul Sharma' },
        amount: 500000,
        project: 'Green Valley Real Estate',
        reason: 'Personal requirement',
        requestedAt: '2026-01-13T08:30:00Z',
        status: 'pending',
    },
    {
        id: 'APR002',
        type: 'investment',
        investor: { id: 'USR003', name: 'Priya Patel' },
        amount: 1000000,
        project: 'TechStart Fund II',
        requestedAt: '2026-01-12T16:00:00Z',
        status: 'pending',
    },
];

// ============================================
// USER SETTINGS
// ============================================
export const userSettings = {
    theme: 'light', // 'light' | 'dark'
    notifications: {
        pushEnabled: true,
        emailEnabled: true,
        reportAlerts: true,
        approvalReminders: true,
        marketUpdates: false,
    },
    language: 'en',
    currency: 'INR',
    biometricEnabled: false,
};

// ============================================
// PORTFOLIO ANALYTICS DATA
// ============================================
export const portfolioAnalytics = {
    monthlyReturns: [
        { month: 'Aug', value: 2.1 },
        { month: 'Sep', value: 3.5 },
        { month: 'Oct', value: 4.2 },
        { month: 'Nov', value: 2.8 },
        { month: 'Dec', value: 5.1 },
        { month: 'Jan', value: 3.2 },
    ],
    assetAllocation: [
        { type: 'Real Estate', percentage: 60, amount: 1725000, color: '#4F46E5' },
        { type: 'Venture Capital', percentage: 40, amount: 1150000, color: '#14B8A6' },
    ],
    performanceMetrics: {
        cagr: 15.0,
        sharpeRatio: 1.8,
        maxDrawdown: -5.2,
        volatility: 8.5,
    },
    yearlyReturns: [
        { year: '2024', return: 12.5 },
        { year: '2025', return: 18.2 },
        { year: '2026 YTD', return: 15.0 },
    ],
};

// ============================================
// ANNOUNCEMENTS DATA
// ============================================
export const announcements = [
    {
        id: 'ANN001',
        title: 'New Investment Opportunity',
        content: 'We are excited to announce a new real estate project in Bangalore. Early investors will get preferential rates.',
        priority: 'high',
        createdAt: '2026-01-14T10:00:00Z',
        createdBy: 'Admin',
        targetAudience: 'all', // 'all' | 'investors' | 'admins'
        read: false,
    },
    {
        id: 'ANN002',
        title: 'Platform Maintenance Notice',
        content: 'Scheduled maintenance on January 20th, 2026 from 2 AM to 4 AM IST. Please plan accordingly.',
        priority: 'medium',
        createdAt: '2026-01-13T15:00:00Z',
        createdBy: 'System',
        targetAudience: 'all',
        read: true,
    },
    {
        id: 'ANN003',
        title: 'Q3 Reports Published',
        content: 'Quarterly reports for all active projects are now available in the Reports section.',
        priority: 'low',
        createdAt: '2026-01-10T09:00:00Z',
        createdBy: 'Admin',
        targetAudience: 'investors',
        read: true,
    },
];

// ============================================
// PROJECT TEMPLATES (for Admin)
// ============================================
export const projectTypes = [
    { id: 'real_estate', label: 'Real Estate', icon: 'business' },
    { id: 'venture_capital', label: 'Venture Capital', icon: 'rocket' },
    { id: 'fixed_income', label: 'Fixed Income', icon: 'trending-up' },
    { id: 'private_equity', label: 'Private Equity', icon: 'briefcase' },
];

export const riskLevels = [
    { id: 'low', label: 'Low Risk', color: '#10B981' },
    { id: 'medium', label: 'Medium Risk', color: '#F59E0B' },
    { id: 'high', label: 'High Risk', color: '#EF4444' },
];

// ============================================
// INVESTORS LIST (for Admin)
// ============================================
export const investors = [
    {
        id: 'USR001',
        name: 'Lohith MS',
        email: 'lohith@investflow.com',
        phone: '+91 98765 43210',
        totalInvested: 2500000,
        activeProjects: 2,
        joinedAt: '2025-05-01',
        status: 'active',
        kycVerified: true,
        // Privacy settings per project
        privacySettings: {
            // Not anonymous in any project
        },
    },
    {
        id: 'USR002',
        name: 'Rahul Sharma',
        email: 'rahul.sharma@email.com',
        phone: '+91 98765 12345',
        totalInvested: 3500000,
        activeProjects: 2,
        joinedAt: '2025-03-15',
        status: 'active',
        kycVerified: true,
        privacySettings: {
            // Visible in all projects (as creator of PRJ001)
        },
    },
    {
        id: 'USR003',
        name: 'Priya Patel',
        email: 'priya.patel@email.com',
        phone: '+91 87654 32109',
        totalInvested: 1000000,
        activeProjects: 1,
        joinedAt: '2025-08-20',
        status: 'active',
        kycVerified: true,
        // Anonymous in PRJ001 (doesn't want Rahul to know her identity)
        privacySettings: {
            'PRJ001': {
                isAnonymous: true,
                displayName: 'Anonymous Investor',
                showInvestmentAmount: false,
            },
        },
    },
    {
        id: 'USR004',
        name: 'Amit Kumar',
        email: 'amit.kumar@email.com',
        phone: '+91 76543 21098',
        totalInvested: 5000000,
        activeProjects: 2,
        joinedAt: '2025-01-10',
        status: 'active',
        kycVerified: true,
        // Anonymous in PRJ002 (doesn't want Lohith's other investors to know)
        privacySettings: {
            'PRJ002': {
                isAnonymous: true,
                displayName: 'Private Investor',
                showInvestmentAmount: false,
            },
        },
    },
];

// ============================================
// HELPER FUNCTIONS
// ============================================
export const simulateApiDelay = (ms = 1000) => {
    return new Promise(resolve => setTimeout(resolve, ms));
};

export const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
    });
};

export const getRelativeTime = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return formatDate(dateString);
};

export const getDaysRemaining = (deadlineString) => {
    const deadline = new Date(deadlineString);
    const now = new Date();
    const diffMs = deadline - now;
    const diffDays = Math.ceil(diffMs / 86400000);
    return diffDays;
};
