import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import {
    View,
    Text,
    ScrollView,
    StyleSheet,
    TouchableOpacity,
    Switch,
    Alert,
    ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { theme } from '../../components/Theme';
import { api } from '../../services/api';

export default function SettingsScreen({ navigation }) {
    const [settings, setSettings] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadSettings();
    }, []);

    const loadSettings = async () => {
        try {
            const data = await api.getSettings();
            setSettings(data);
        } catch (error) {
            Alert.alert('Error', 'Failed to load settings');
        } finally {
            setLoading(false);
        }
    };

    const updateNotificationSetting = async (key, value) => {
        const newSettings = {
            ...settings,
            notifications: {
                ...settings.notifications,
                [key]: value,
            },
        };
        setSettings(newSettings);
        await api.updateNotificationPreferences({ [key]: value });
    };

    const updateSetting = async (key, value) => {
        const newSettings = { ...settings, [key]: value };
        setSettings(newSettings);
        await api.updateSettings({ [key]: value });
    };

    if (loading) {
        return (
            <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color={theme.colors.primary} />
            </View>
        );
    }

    const SettingRow = ({ icon, title, subtitle, value, onToggle, showArrow }) => (
        <View style={styles.settingRow}>
            <View style={styles.settingIcon}>
                <Ionicons name={icon} size={22} color={theme.colors.primary} />
            </View>
            <View style={styles.settingContent}>
                <Text style={styles.settingTitle}>{title}</Text>
                {subtitle && <Text style={styles.settingSubtitle}>{subtitle}</Text>}
            </View>
            {onToggle !== undefined && (
                <Switch
                    value={value}
                    onValueChange={onToggle}
                    trackColor={{ false: theme.colors.border, true: theme.colors.primaryLight }}
                    thumbColor={value ? theme.colors.primary : theme.colors.textTertiary}
                />
            )}
            {showArrow && (
                <Ionicons name="chevron-forward" size={20} color={theme.colors.textTertiary} />
            )}
        </View>
    );

    SettingRow.propTypes = {
        icon: PropTypes.string.isRequired,
        title: PropTypes.string.isRequired,
        subtitle: PropTypes.string,
        value: PropTypes.bool,
        onToggle: PropTypes.func,
        showArrow: PropTypes.bool,
    };

    return (
        <SafeAreaView style={styles.container}>
            {/* Header */}
            <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
                    <Ionicons name="arrow-back" size={24} color={theme.colors.textPrimary} />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Settings</Text>
                <View style={{ width: 32 }} />
            </View>

            <ScrollView showsVerticalScrollIndicator={false}>
                {/* Appearance */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Appearance</Text>
                    <SettingRow
                        icon="moon-outline"
                        title="Dark Mode"
                        subtitle="Use dark theme"
                        value={settings?.theme === 'dark'}
                        onToggle={(val) => updateSetting('theme', val ? 'dark' : 'light')}
                    />
                    <SettingRow
                        icon="finger-print-outline"
                        title="Biometric Login"
                        subtitle="Use fingerprint or face ID"
                        value={settings?.biometricEnabled}
                        onToggle={(val) => updateSetting('biometricEnabled', val)}
                    />
                </View>

                {/* Notifications */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Notifications</Text>
                    <SettingRow
                        icon="notifications-outline"
                        title="Push Notifications"
                        subtitle="Receive push notifications"
                        value={settings?.notifications?.pushEnabled}
                        onToggle={(val) => updateNotificationSetting('pushEnabled', val)}
                    />
                    <SettingRow
                        icon="mail-outline"
                        title="Email Notifications"
                        subtitle="Receive email updates"
                        value={settings?.notifications?.emailEnabled}
                        onToggle={(val) => updateNotificationSetting('emailEnabled', val)}
                    />
                    <SettingRow
                        icon="document-text-outline"
                        title="Report Alerts"
                        subtitle="Get notified when reports are ready"
                        value={settings?.notifications?.reportAlerts}
                        onToggle={(val) => updateNotificationSetting('reportAlerts', val)}
                    />
                    <SettingRow
                        icon="checkbox-outline"
                        title="Approval Reminders"
                        subtitle="Remind about pending approvals"
                        value={settings?.notifications?.approvalReminders}
                        onToggle={(val) => updateNotificationSetting('approvalReminders', val)}
                    />
                    <SettingRow
                        icon="trending-up-outline"
                        title="Market Updates"
                        subtitle="Receive market news"
                        value={settings?.notifications?.marketUpdates}
                        onToggle={(val) => updateNotificationSetting('marketUpdates', val)}
                    />
                </View>

                {/* General */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>General</Text>
                    <TouchableOpacity
                        style={styles.settingRow}
                        onPress={() => Alert.alert('Language', 'Language options: English')}
                    >
                        <View style={styles.settingIcon}>
                            <Ionicons name="language-outline" size={22} color={theme.colors.primary} />
                        </View>
                        <View style={styles.settingContent}>
                            <Text style={styles.settingTitle}>Language</Text>
                            <Text style={styles.settingSubtitle}>English</Text>
                        </View>
                        <Ionicons name="chevron-forward" size={20} color={theme.colors.textTertiary} />
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={styles.settingRow}
                        onPress={() => Alert.alert('Currency', 'Currency: INR (₹)')}
                    >
                        <View style={styles.settingIcon}>
                            <Ionicons name="cash-outline" size={22} color={theme.colors.primary} />
                        </View>
                        <View style={styles.settingContent}>
                            <Text style={styles.settingTitle}>Currency</Text>
                            <Text style={styles.settingSubtitle}>INR (₹)</Text>
                        </View>
                        <Ionicons name="chevron-forward" size={20} color={theme.colors.textTertiary} />
                    </TouchableOpacity>
                </View>

                {/* Support */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Support</Text>
                    <TouchableOpacity
                        style={styles.settingRow}
                        onPress={() => Alert.alert('Help Center', 'Visit our support portal for assistance.')}
                    >
                        <View style={styles.settingIcon}>
                            <Ionicons name="help-circle-outline" size={22} color={theme.colors.primary} />
                        </View>
                        <View style={styles.settingContent}>
                            <Text style={styles.settingTitle}>Help Center</Text>
                        </View>
                        <Ionicons name="chevron-forward" size={20} color={theme.colors.textTertiary} />
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={styles.settingRow}
                        onPress={() => Alert.alert('Privacy Policy', 'View our privacy policy online.')}
                    >
                        <View style={styles.settingIcon}>
                            <Ionicons name="shield-outline" size={22} color={theme.colors.primary} />
                        </View>
                        <View style={styles.settingContent}>
                            <Text style={styles.settingTitle}>Privacy Policy</Text>
                        </View>
                        <Ionicons name="chevron-forward" size={20} color={theme.colors.textTertiary} />
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={styles.settingRow}
                        onPress={() => Alert.alert('Terms of Service', 'View our terms of service.')}
                    >
                        <View style={styles.settingIcon}>
                            <Ionicons name="document-outline" size={22} color={theme.colors.primary} />
                        </View>
                        <View style={styles.settingContent}>
                            <Text style={styles.settingTitle}>Terms of Service</Text>
                        </View>
                        <Ionicons name="chevron-forward" size={20} color={theme.colors.textTertiary} />
                    </TouchableOpacity>
                </View>

                {/* About */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>About</Text>
                    <View style={styles.settingRow}>
                        <View style={styles.settingIcon}>
                            <Ionicons name="information-circle-outline" size={22} color={theme.colors.primary} />
                        </View>
                        <View style={styles.settingContent}>
                            <Text style={styles.settingTitle}>App Version</Text>
                            <Text style={styles.settingSubtitle}>1.0.0</Text>
                        </View>
                    </View>
                </View>

                <View style={{ height: 40 }} />
            </ScrollView>
        </SafeAreaView>
    );
}

SettingsScreen.propTypes = {
    navigation: PropTypes.shape({
        goBack: PropTypes.func.isRequired,
    }).isRequired,
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.colors.background,
    },
    loadingContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: theme.colors.background,
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 16,
        paddingVertical: 12,
        backgroundColor: theme.colors.surface,
        borderBottomWidth: 1,
        borderBottomColor: theme.colors.border,
    },
    backButton: {
        padding: 4,
    },
    headerTitle: {
        fontSize: 18,
        fontWeight: '600',
        color: theme.colors.textPrimary,
    },
    section: {
        backgroundColor: theme.colors.surface,
        marginTop: 16,
        paddingHorizontal: 16,
    },
    sectionTitle: {
        fontSize: 13,
        fontWeight: '600',
        color: theme.colors.textSecondary,
        textTransform: 'uppercase',
        letterSpacing: 0.5,
        paddingTop: 16,
        paddingBottom: 8,
    },
    settingRow: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 14,
        borderBottomWidth: 1,
        borderBottomColor: theme.colors.borderLight,
    },
    settingIcon: {
        width: 36,
        height: 36,
        borderRadius: 8,
        backgroundColor: theme.colors.primaryLight,
        justifyContent: 'center',
        alignItems: 'center',
    },
    settingContent: {
        flex: 1,
        marginLeft: 12,
    },
    settingTitle: {
        fontSize: 16,
        fontWeight: '500',
        color: theme.colors.textPrimary,
    },
    settingSubtitle: {
        fontSize: 13,
        color: theme.colors.textSecondary,
        marginTop: 2,
    },
});
