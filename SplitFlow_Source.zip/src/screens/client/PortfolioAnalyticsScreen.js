import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import {
    View,
    Text,
    ScrollView,
    StyleSheet,
    TouchableOpacity,
    Alert,
    ActivityIndicator,
    Animated,
    Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { theme, formatCurrency } from '../../components/Theme';
import { api } from '../../services/api';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const CARD_PADDING = 16;
const CARD_MARGIN = 16;
const METRICS_GAP = 10;
const METRIC_CARD_WIDTH = (SCREEN_WIDTH - (CARD_MARGIN * 2) - (CARD_PADDING * 2) - (METRICS_GAP * 3)) / 4;

export default function PortfolioAnalyticsScreen({ navigation }) {
    const [analytics, setAnalytics] = useState(null);
    const [loading, setLoading] = useState(true);
    const [selectedPeriod, setSelectedPeriod] = useState('6M');
    const fadeAnim = useRef(new Animated.Value(0)).current;
    const slideAnim = useRef(new Animated.Value(30)).current;

    useEffect(() => {
        loadAnalytics();
    }, []);

    useEffect(() => {
        if (!loading) {
            Animated.parallel([
                Animated.timing(fadeAnim, {
                    toValue: 1,
                    duration: 500,
                    useNativeDriver: true,
                }),
                Animated.timing(slideAnim, {
                    toValue: 0,
                    duration: 500,
                    useNativeDriver: true,
                }),
            ]).start();
        }
    }, [loading]);

    const loadAnalytics = async () => {
        try {
            const data = await api.getPortfolioAnalytics();
            setAnalytics(data);
        } catch (error) {
            Alert.alert('Error', 'Failed to load analytics');
        } finally {
            setLoading(false);
        }
    };

    const periods = ['1M', '3M', '6M', '1Y', 'ALL'];

    if (loading) {
        return (
            <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color={theme.colors.primary} />
            </View>
        );
    }

    const MetricCard = ({ label, value, suffix, color, icon }) => (
        <LinearGradient
            colors={['#FFFFFF', '#F8FAFC']}
            style={styles.metricCard}
        >
            <View style={[styles.metricIconContainer, { backgroundColor: (color || theme.colors.primary) + '15' }]}>
                <Ionicons name={icon || 'stats-chart'} size={18} color={color || theme.colors.primary} />
            </View>
            <Text style={styles.metricLabel} numberOfLines={1}>{label}</Text>
            <Text style={[styles.metricValue, { color: color || theme.colors.textPrimary }]} numberOfLines={1}>
                {value}{suffix}
            </Text>
        </LinearGradient>
    );

    MetricCard.propTypes = {
        label: PropTypes.string.isRequired,
        value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
        suffix: PropTypes.string,
        color: PropTypes.string,
        icon: PropTypes.string,
    };

    const renderChart = () => {
        const data = analytics?.monthlyReturns || [];
        const maxValue = Math.max(...data.map(d => d.value));

        return (
            <View style={styles.chartContainer}>
                <View style={styles.chartBars}>
                    {data.map((item) => (
                        <View key={item.month} style={styles.barColumn}>
                            <Text style={styles.barValue}>{item.value}%</Text>
                            <View style={styles.barWrapper}>
                                <LinearGradient
                                    colors={[theme.colors.primary, theme.colors.primaryDark]}
                                    style={[
                                        styles.bar,
                                        { height: `${(item.value / maxValue) * 100}%` },
                                    ]}
                                />
                            </View>
                            <Text style={styles.barLabel}>{item.month}</Text>
                        </View>
                    ))}
                </View>
            </View>
        );
    };

    const renderAllocationPie = () => {
        const data = analytics?.assetAllocation || [];

        return (
            <View style={styles.allocationContainer}>
                <View style={styles.pieChart}>
                    {data.map((item) => (
                        <View
                            key={item.type}
                            style={[
                                styles.pieSegment,
                                {
                                    backgroundColor: item.color,
                                    width: item.percentage + '%',
                                },
                            ]}
                        />
                    ))}
                </View>
                <View style={styles.allocationLegend}>
                    {data.map((item) => (
                        <View key={item.type} style={styles.legendItem}>
                            <View style={[styles.legendDot, { backgroundColor: item.color }]} />
                            <Text style={styles.legendLabel} numberOfLines={1}>{item.type}</Text>
                            <Text style={styles.legendPercent}>{item.percentage}%</Text>
                            <Text style={styles.legendAmount}>{formatCurrency(item.amount)}</Text>
                        </View>
                    ))}
                </View>
            </View>
        );
    };

    return (
        <SafeAreaView style={styles.container}>
            {/* Header */}
            <View style={styles.header}>
                <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
                    <Ionicons name="arrow-back" size={24} color={theme.colors.textPrimary} />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Portfolio Analytics</Text>
                <TouchableOpacity style={styles.headerAction}>
                    <Ionicons name="share-outline" size={22} color={theme.colors.primary} />
                </TouchableOpacity>
            </View>

            <Animated.ScrollView
                showsVerticalScrollIndicator={false}
                style={{ opacity: fadeAnim, transform: [{ translateY: slideAnim }] }}
                contentContainerStyle={styles.scrollContent}
            >
                {/* Period Selector */}
                <View style={styles.periodSelector}>
                    {periods.map((period) => (
                        <TouchableOpacity
                            key={period}
                            style={[
                                styles.periodButton,
                                selectedPeriod === period && styles.periodButtonActive,
                            ]}
                            onPress={() => setSelectedPeriod(period)}
                        >
                            <Text
                                style={[
                                    styles.periodText,
                                    selectedPeriod === period && styles.periodTextActive,
                                ]}
                            >
                                {period}
                            </Text>
                        </TouchableOpacity>
                    ))}
                </View>

                {/* Key Metrics - Horizontal ScrollView */}
                <Text style={styles.sectionHeader}>Performance Metrics</Text>
                <ScrollView
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    contentContainerStyle={styles.metricsScroll}
                >
                    <MetricCard
                        label="CAGR"
                        value={analytics?.performanceMetrics?.cagr}
                        suffix="%"
                        color={theme.colors.success}
                        icon="trending-up"
                    />
                    <MetricCard
                        label="Sharpe"
                        value={analytics?.performanceMetrics?.sharpeRatio}
                        color={theme.colors.primary}
                        icon="analytics"
                    />
                    <MetricCard
                        label="Drawdown"
                        value={analytics?.performanceMetrics?.maxDrawdown}
                        suffix="%"
                        color={theme.colors.danger}
                        icon="trending-down"
                    />
                    <MetricCard
                        label="Volatility"
                        value={analytics?.performanceMetrics?.volatility}
                        suffix="%"
                        color={theme.colors.warning}
                        icon="pulse"
                    />
                </ScrollView>

                {/* Performance Chart */}
                <View style={styles.section}>
                    <View style={styles.sectionTitleRow}>
                        <Text style={styles.sectionTitle}>Monthly Returns</Text>
                        <View style={styles.sectionBadge}>
                            <Text style={styles.sectionBadgeText}>6 Months</Text>
                        </View>
                    </View>
                    {renderChart()}
                </View>

                {/* Asset Allocation */}
                <View style={styles.section}>
                    <View style={styles.sectionTitleRow}>
                        <Text style={styles.sectionTitle}>Asset Allocation</Text>
                        <Ionicons name="pie-chart" size={18} color={theme.colors.textSecondary} />
                    </View>
                    {renderAllocationPie()}
                </View>

                {/* Yearly Returns */}
                <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Yearly Returns</Text>
                    <View style={styles.yearlyContainer}>
                        {analytics?.yearlyReturns?.map((item) => (
                            <View key={item.year} style={styles.yearlyRow}>
                                <Text style={styles.yearLabel}>{item.year}</Text>
                                <View style={styles.yearBarContainer}>
                                    <Animated.View
                                        style={[
                                            styles.yearBar,
                                            {
                                                width: `${Math.min(Math.abs(item.return) * 5, 100)}%`,
                                                backgroundColor: item.return > 0 ? theme.colors.success : theme.colors.danger,
                                            },
                                        ]}
                                    />
                                </View>
                                <Text style={[
                                    styles.yearValue,
                                    { color: item.return > 0 ? theme.colors.success : theme.colors.danger }
                                ]}>
                                    {item.return > 0 ? '+' : ''}{item.return}%
                                </Text>
                            </View>
                        ))}
                    </View>
                </View>

                {/* Info Card */}
                <View style={styles.infoCard}>
                    <View style={styles.infoIconContainer}>
                        <Ionicons name="information-circle" size={20} color={theme.colors.info} />
                    </View>
                    <Text style={styles.infoText}>
                        Past performance is not indicative of future results. Returns are net of fees.
                    </Text>
                </View>

                <View style={{ height: 24 }} />
            </Animated.ScrollView>
        </SafeAreaView>
    );
}

PortfolioAnalyticsScreen.propTypes = {
    navigation: PropTypes.shape({
        goBack: PropTypes.func.isRequired,
    }).isRequired,
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.colors.background,
    },
    loadingContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: theme.colors.background,
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        paddingHorizontal: 16,
        paddingVertical: 12,
        backgroundColor: theme.colors.surface,
        borderBottomWidth: 1,
        borderBottomColor: theme.colors.border,
    },
    backButton: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: theme.colors.surfaceAlt,
        justifyContent: 'center',
        alignItems: 'center',
    },
    headerTitle: {
        fontSize: 17,
        fontWeight: '600',
        color: theme.colors.textPrimary,
    },
    headerAction: {
        width: 40,
        height: 40,
        borderRadius: 20,
        backgroundColor: theme.colors.primaryLight,
        justifyContent: 'center',
        alignItems: 'center',
    },
    scrollContent: {
        paddingBottom: 16,
    },
    periodSelector: {
        flexDirection: 'row',
        paddingHorizontal: 16,
        paddingVertical: 12,
        gap: 8,
    },
    periodButton: {
        flex: 1,
        paddingVertical: 8,
        borderRadius: 20,
        backgroundColor: theme.colors.surface,
        alignItems: 'center',
        borderWidth: 1,
        borderColor: theme.colors.border,
    },
    periodButtonActive: {
        backgroundColor: theme.colors.primary,
        borderColor: theme.colors.primary,
    },
    periodText: {
        fontSize: 13,
        fontWeight: '600',
        color: theme.colors.textSecondary,
    },
    periodTextActive: {
        color: 'white',
    },
    sectionHeader: {
        fontSize: 15,
        fontWeight: '600',
        color: theme.colors.textPrimary,
        paddingHorizontal: 16,
        marginTop: 8,
        marginBottom: 12,
    },
    metricsScroll: {
        paddingHorizontal: 16,
        gap: 10,
    },
    metricCard: {
        width: 100,
        backgroundColor: theme.colors.surface,
        borderRadius: 18,
        padding: 14,
        alignItems: 'center',
        ...theme.shadows.soft,
        borderWidth: 1,
        borderColor: theme.colors.surfaceAlt,
    },
    metricIconContainer: {
        width: 32,
        height: 32,
        borderRadius: 10,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 8,
    },
    metricLabel: {
        fontSize: 10,
        color: theme.colors.textSecondary,
        textTransform: 'uppercase',
        letterSpacing: 0.3,
        marginBottom: 4,
    },
    metricValue: {
        fontSize: 16,
        fontWeight: '700',
    },
    section: {
        backgroundColor: theme.colors.surface,
        marginHorizontal: 16,
        marginTop: 16,
        borderRadius: 16,
        padding: 16,
        ...theme.shadows.card,
    },
    sectionTitleRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 16,
    },
    sectionTitle: {
        fontSize: 16,
        fontWeight: '600',
        color: theme.colors.textPrimary,
    },
    sectionBadge: {
        backgroundColor: theme.colors.primaryLight,
        paddingHorizontal: 10,
        paddingVertical: 4,
        borderRadius: 12,
    },
    sectionBadgeText: {
        fontSize: 11,
        fontWeight: '600',
        color: theme.colors.primary,
    },
    chartContainer: {
        height: 180,
    },
    chartBars: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'flex-end',
        justifyContent: 'space-between',
    },
    barColumn: {
        flex: 1,
        alignItems: 'center',
        paddingHorizontal: 4,
    },
    barValue: {
        fontSize: 9,
        fontWeight: '600',
        color: theme.colors.textSecondary,
        marginBottom: 4,
    },
    barWrapper: {
        width: '100%',
        height: 130,
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    bar: {
        width: '70%',
        borderRadius: 6,
        minHeight: 8,
    },
    barLabel: {
        fontSize: 10,
        fontWeight: '500',
        color: theme.colors.textSecondary,
        marginTop: 6,
    },
    allocationContainer: {
        marginTop: 4,
    },
    pieChart: {
        height: 16,
        flexDirection: 'row',
        borderRadius: 8,
        overflow: 'hidden',
    },
    pieSegment: {
        height: '100%',
    },
    allocationLegend: {
        marginTop: 16,
    },
    legendItem: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 10,
        borderBottomWidth: 1,
        borderBottomColor: theme.colors.borderLight,
    },
    legendDot: {
        width: 10,
        height: 10,
        borderRadius: 5,
    },
    legendLabel: {
        flex: 1,
        fontSize: 14,
        fontWeight: '500',
        color: theme.colors.textPrimary,
        marginLeft: 10,
    },
    legendPercent: {
        fontSize: 14,
        fontWeight: '600',
        color: theme.colors.textPrimary,
        marginRight: 12,
    },
    legendAmount: {
        fontSize: 13,
        color: theme.colors.textSecondary,
        minWidth: 70,
        textAlign: 'right',
    },
    yearlyContainer: {
        marginTop: 8,
    },
    yearlyRow: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 10,
    },
    yearLabel: {
        width: 70,
        fontSize: 13,
        fontWeight: '500',
        color: theme.colors.textPrimary,
    },
    yearBarContainer: {
        flex: 1,
        height: 6,
        backgroundColor: theme.colors.surfaceAlt,
        borderRadius: 3,
        marginHorizontal: 10,
        overflow: 'hidden',
    },
    yearBar: {
        height: '100%',
        borderRadius: 3,
    },
    yearValue: {
        width: 50,
        fontSize: 13,
        fontWeight: '600',
        textAlign: 'right',
    },
    infoCard: {
        flexDirection: 'row',
        backgroundColor: theme.colors.infoLight,
        marginHorizontal: 16,
        marginTop: 16,
        borderRadius: 12,
        padding: 14,
        alignItems: 'center',
    },
    infoIconContainer: {
        width: 32,
        height: 32,
        borderRadius: 16,
        backgroundColor: 'rgba(59, 130, 246, 0.15)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    infoText: {
        flex: 1,
        fontSize: 12,
        color: theme.colors.info,
        marginLeft: 12,
        lineHeight: 16,
    },
});
