import React from 'react';
import {
    View,
    Text,
    ScrollView,
    StyleSheet,
    TouchableOpacity,
    StatusBar,
    Image,
    Alert
} from 'react-native';
import { theme } from '../components/Theme';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

export default function DashboardScreen({ user, navigation, onLogout }) {

    const handleProfilePress = () => {
        Alert.alert(
            "Account Options",
            "What would you like to do?",
            [
                { text: "My Profile", onPress: () => Alert.alert("Coming Soon", "Profile feature is under development") },
                { text: "Settings", onPress: () => Alert.alert("Coming Soon", "Settings feature is under development") },
                {
                    text: "Logout",
                    onPress: onLogout,
                    style: "destructive"
                },
                { text: "Cancel", style: "cancel" }
            ],
            { cancelable: true }
        );
    };

    const RecentActivity = [
        { id: 1, title: "Dinner at Mario's", group: "Roommates", amount: "₹450", type: "expense", date: "Today" },
        { id: 2, title: "Grocery Shopping", group: "Home", amount: "₹1,200", type: "payment", date: "Yesterday" },
        { id: 3, title: "Movie Night", group: "Friends", amount: "₹850", type: "expense", date: "Oct 24" },
    ];

    return (
        <View style={styles.container}>
            <StatusBar barStyle="dark-content" />

            {/* Header */}
            <View style={styles.header}>
                <View>
                    <Text style={styles.headerLabel}>Welcome back,</Text>
                    <Text style={styles.headerName}>Lohith MS</Text>
                </View>
                <TouchableOpacity style={styles.profileBtn} onPress={handleProfilePress}>
                    <Text style={styles.profileInitials}>LM</Text>
                </TouchableOpacity>
            </View>

            <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
                {/* Balance Card */}
                <LinearGradient
                    colors={['#1e293b', '#0f172a']}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    style={styles.balanceCard}
                >
                    <Text style={styles.balanceLabel}>Total Balance</Text>
                    <Text style={styles.balanceValue}>₹12,450</Text>

                    <View style={styles.balanceRow}>
                        <View style={styles.balanceItem}>
                            <View style={[styles.iconCircle, { backgroundColor: 'rgba(16, 185, 129, 0.2)' }]}>
                                <Ionicons name="arrow-down" size={12} color={theme.colors.success} />
                            </View>
                            <Text style={styles.balanceMetaLabel}>You are owed</Text>
                            <Text style={[styles.balanceMetaValue, { color: theme.colors.success }]}>₹14,500</Text>
                        </View>

                        <View style={styles.divider} />

                        <View style={styles.balanceItem}>
                            <View style={[styles.iconCircle, { backgroundColor: 'rgba(239, 68, 68, 0.2)' }]}>
                                <Ionicons name="arrow-up" size={12} color={theme.colors.danger} />
                            </View>
                            <Text style={styles.balanceMetaLabel}>You owe</Text>
                            <Text style={[styles.balanceMetaValue, { color: theme.colors.danger }]}>₹2,050</Text>
                        </View>
                    </View>
                </LinearGradient>

                {/* Quick Actions */}
                <View style={styles.sectionHeader}>
                    <Text style={styles.sectionTitle}>Groups</Text>
                    <TouchableOpacity onPress={() => Alert.alert("Coming Soon", "All groups view is under development")}>
                        <Text style={styles.seeAll}>See All</Text>
                    </TouchableOpacity>
                </View>

                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.groupsScroll}>
                    {['Trip to Goa', 'Roommates', 'Office Lunch'].map((group, index) => (
                        <TouchableOpacity
                            key={index}
                            style={styles.groupCard}
                            onPress={() => Alert.alert("Group Details", `"${group}" details coming soon!`)}
                        >
                            <View style={[styles.groupIcon, { backgroundColor: index === 0 ? '#FDE68A' : '#E0E7FF' }]} />
                            <Text style={styles.groupName}>{group}</Text>
                            <Text style={styles.groupMeta}>Settled up</Text>
                        </TouchableOpacity>
                    ))}
                    <TouchableOpacity
                        style={[styles.groupCard, styles.addGroupCard]}
                        onPress={() => Alert.alert("Coming Soon", "Create new group feature is under development")}
                    >
                        <Ionicons name="add" size={24} color={theme.colors.textSecondary} />
                        <Text style={styles.groupMeta}>Create</Text>
                    </TouchableOpacity>
                </ScrollView>

                {/* Recent Activity */}
                <View style={styles.sectionHeader}>
                    <Text style={styles.sectionTitle}>Recent Activity</Text>
                </View>

                <View style={styles.activityList}>
                    {RecentActivity.map((item) => (
                        <View key={item.id} style={styles.activityItem}>
                            <View style={[styles.activityIcon, { backgroundColor: item.type === 'expense' ? '#FEE2E2' : '#D1FAE5' }]}>
                                <Ionicons
                                    name={item.type === 'expense' ? 'receipt-outline' : 'cash-outline'}
                                    size={20}
                                    color={item.type === 'expense' ? theme.colors.danger : theme.colors.success}
                                />
                            </View>
                            <View style={styles.activityContent}>
                                <Text style={styles.activityTitle}>{item.title}</Text>
                                <Text style={styles.activitySubtitle}>{item.group} • {item.date}</Text>
                            </View>
                            <Text style={[styles.activityAmount, { color: item.type === 'expense' ? theme.colors.textPrimary : theme.colors.success }]}>
                                {item.type === 'expense' ? '-' : '+'}{item.amount}
                            </Text>
                        </View>
                    ))}
                </View>
            </ScrollView>

            {/* FAB */}
            <TouchableOpacity style={styles.fab} onPress={() => navigation.navigate('AddExpense')}>
                <Ionicons name="add" size={32} color="white" />
            </TouchableOpacity>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.colors.background,
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: theme.spacing.l,
        paddingTop: theme.spacing.l,
        paddingBottom: theme.spacing.m,
    },
    headerLabel: {
        fontSize: 14,
        color: theme.colors.textSecondary,
    },
    headerName: {
        fontSize: 20,
        fontWeight: '700',
        color: theme.colors.textPrimary,
    },
    profileBtn: {
        width: 44,
        height: 44,
        borderRadius: 22,
        backgroundColor: theme.colors.primary,
        alignItems: 'center',
        justifyContent: 'center',
        ...theme.shadows.soft,
    },
    profileInitials: {
        color: 'white',
        fontWeight: '700',
        fontSize: 16,
    },
    scrollContent: {
        paddingBottom: 80,
    },
    balanceCard: {
        margin: theme.spacing.l,
        padding: theme.spacing.l,
        borderRadius: theme.borderRadius.xl,
        marginTop: theme.spacing.s,
        ...theme.shadows.glow,
    },
    balanceLabel: {
        color: 'rgba(255,255,255,0.7)',
        fontSize: 14,
        marginBottom: 4,
    },
    balanceValue: {
        color: 'white',
        fontSize: 32,
        fontWeight: '700',
        marginBottom: theme.spacing.l,
    },
    balanceRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    balanceItem: {
        flex: 1,
    },
    iconCircle: {
        width: 24,
        height: 24,
        borderRadius: 12,
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 4,
    },
    balanceMetaLabel: {
        color: 'rgba(255,255,255,0.7)',
        fontSize: 12,
    },
    balanceMetaValue: {
        fontSize: 16,
        fontWeight: '600',
        marginTop: 2,
    },
    divider: {
        width: 1,
        backgroundColor: 'rgba(255,255,255,0.1)',
        marginHorizontal: theme.spacing.m,
    },
    sectionHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: theme.spacing.l,
        marginBottom: theme.spacing.m,
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: '600',
        color: theme.colors.textPrimary,
    },
    seeAll: {
        color: theme.colors.primary,
        fontSize: 14,
        fontWeight: '500',
    },
    groupsScroll: {
        paddingLeft: theme.spacing.l,
        marginBottom: theme.spacing.xl,
    },
    groupCard: {
        width: 120,
        padding: theme.spacing.m,
        backgroundColor: theme.colors.surface,
        borderRadius: theme.borderRadius.l,
        marginRight: theme.spacing.m,
        ...theme.shadows.card,
    },
    addGroupCard: {
        alignItems: 'center',
        justifyContent: 'center',
        borderWidth: 1,
        borderColor: theme.colors.border,
        backgroundColor: 'transparent',
        shadowOpacity: 0,
    },
    groupIcon: {
        width: 40,
        height: 40,
        borderRadius: 12,
        marginBottom: theme.spacing.s,
    },
    groupName: {
        fontSize: 14,
        fontWeight: '600',
        color: theme.colors.textPrimary,
        marginBottom: 4,
    },
    groupMeta: {
        fontSize: 12,
        color: theme.colors.textSecondary,
    },
    activityList: {
        paddingHorizontal: theme.spacing.l,
        gap: theme.spacing.m,
    },
    activityItem: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: theme.colors.surface,
        padding: theme.spacing.m,
        borderRadius: theme.borderRadius.m,
        ...theme.shadows.soft,
    },
    activityIcon: {
        width: 40,
        height: 40,
        borderRadius: 20,
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: theme.spacing.m,
    },
    activityContent: {
        flex: 1,
    },
    activityTitle: {
        fontSize: 16,
        fontWeight: '500',
        color: theme.colors.textPrimary,
    },
    activitySubtitle: {
        fontSize: 12,
        color: theme.colors.textSecondary,
        marginTop: 2,
    },
    activityAmount: {
        fontSize: 16,
        fontWeight: '600',
    },
    fab: {
        position: 'absolute',
        bottom: 24,
        right: 24,
        width: 56,
        height: 56,
        borderRadius: 28,
        backgroundColor: theme.colors.primary,
        alignItems: 'center',
        justifyContent: 'center',
        ...theme.shadows.glow,
    },
});
