import React, { useState } from 'react';
import PropTypes from 'prop-types';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    StyleSheet,
    KeyboardAvoidingView,
    Platform,
    Alert,
    StatusBar,
    Dimensions,
    ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { theme } from '../components/Theme';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

/**
 * Test Accounts for Privacy Feature Testing
 */
const TEST_ACCOUNTS = [
    {
        id: 'USR001',
        name: 'Lohith MS',
        email: 'lohith@investflow.com',
        password: 'lohith123',
        description: 'Admin of TechStart Fund II',
    },
    {
        id: 'USR002',
        name: 'Rahul Sharma',
        email: 'rahul@investflow.com',
        password: 'rahul123',
        description: 'Admin of Green Valley Real Estate',
    },
    {
        id: 'USR003',
        name: 'Priya Patel',
        email: 'priya@investflow.com',
        password: 'priya123',
        description: 'Anonymous in PRJ001 (test privacy)',
    },
];

/**
 * LoginScreen with Multi-Account Support
 */
export default function LoginScreen({ onLogin, onLoginWithUser }) {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [emailFocused, setEmailFocused] = useState(false);
    const [passwordFocused, setPasswordFocused] = useState(false);
    const [showTestAccounts, setShowTestAccounts] = useState(false);

    const handleLogin = () => {
        if (!email.trim()) {
            Alert.alert('Required', 'Please enter your email address');
            return;
        }
        if (!password.trim()) {
            Alert.alert('Required', 'Please enter your password');
            return;
        }

        // Check against test accounts
        const account = TEST_ACCOUNTS.find(a =>
            a.email.toLowerCase() === email.toLowerCase() && a.password === password
        );

        if (!account) {
            // Fallback to old demo password
            if (password === 'investor123') {
                setIsLoading(true);
                setTimeout(() => {
                    setIsLoading(false);
                    onLogin?.(TEST_ACCOUNTS[0].id); // Default to Lohith
                }, 500);
                return;
            }
            Alert.alert('Login Failed', 'Invalid email or password', [{ text: 'OK' }]);
            return;
        }

        setIsLoading(true);
        setTimeout(() => {
            setIsLoading(false);
            onLogin?.(account.id);
        }, 500);
    };

    const handleQuickLogin = (account) => {
        setIsLoading(true);
        setTimeout(() => {
            setIsLoading(false);
            onLogin?.(account.id);
        }, 300);
    };

    return (
        <SafeAreaView style={styles.container}>
            <StatusBar barStyle="dark-content" backgroundColor={theme.colors.background} />
            <ScrollView
                contentContainerStyle={styles.scrollContent}
                keyboardShouldPersistTaps="handled"
                showsVerticalScrollIndicator={false}
            >
                <KeyboardAvoidingView
                    behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
                    style={styles.keyboardView}
                >
                    {/* Logo & Branding */}
                    <View style={styles.header}>
                        <View style={styles.logoBox}>
                            <LinearGradient colors={['#6366F1', '#8B5CF6']} style={styles.logoGradient}>
                                <MaterialCommunityIcons name="trending-up" size={36} color="white" />
                            </LinearGradient>
                        </View>
                        <Text style={styles.appName}>InvestFlow</Text>
                        <Text style={styles.tagline}>Smart investing, simplified</Text>
                    </View>

                    {/* Login Card */}
                    <View style={styles.card}>
                        <Text style={styles.cardTitle}>Sign In</Text>
                        <Text style={styles.cardSubtitle}>Welcome back to your portfolio</Text>

                        {/* Email Field */}
                        <View style={[styles.inputContainer, emailFocused && styles.inputFocused]}>
                            <MaterialCommunityIcons
                                name="email-outline"
                                size={22}
                                color={emailFocused ? theme.colors.primary : theme.colors.textTertiary}
                            />
                            <TextInput
                                style={styles.input}
                                placeholder="Email address"
                                placeholderTextColor={theme.colors.textTertiary}
                                value={email}
                                onChangeText={setEmail}
                                keyboardType="email-address"
                                autoCapitalize="none"
                                autoCorrect={false}
                                onFocus={() => setEmailFocused(true)}
                                onBlur={() => setEmailFocused(false)}
                            />
                        </View>

                        {/* Password Field */}
                        <View style={[styles.inputContainer, passwordFocused && styles.inputFocused]}>
                            <MaterialCommunityIcons
                                name="lock-outline"
                                size={22}
                                color={passwordFocused ? theme.colors.primary : theme.colors.textTertiary}
                            />
                            <TextInput
                                style={styles.input}
                                placeholder="Password"
                                placeholderTextColor={theme.colors.textTertiary}
                                value={password}
                                onChangeText={setPassword}
                                secureTextEntry={!showPassword}
                                onFocus={() => setPasswordFocused(true)}
                                onBlur={() => setPasswordFocused(false)}
                            />
                            <TouchableOpacity
                                onPress={() => setShowPassword(!showPassword)}
                                hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                            >
                                <MaterialCommunityIcons
                                    name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                                    size={22}
                                    color={theme.colors.textTertiary}
                                />
                            </TouchableOpacity>
                        </View>

                        {/* Sign In Button */}
                        <TouchableOpacity
                            style={styles.signInButton}
                            onPress={handleLogin}
                            disabled={isLoading}
                            activeOpacity={0.8}
                        >
                            <LinearGradient colors={['#6366F1', '#4F46E5']} style={styles.signInGradient}>
                                {isLoading ? (
                                    <Text style={styles.signInText}>Signing in...</Text>
                                ) : (
                                    <>
                                        <Text style={styles.signInText}>Sign In</Text>
                                        <MaterialCommunityIcons name="arrow-right" size={20} color="white" />
                                    </>
                                )}
                            </LinearGradient>
                        </TouchableOpacity>
                    </View>

                    {/* Test Accounts Section */}
                    <TouchableOpacity
                        style={styles.testAccountsHeader}
                        onPress={() => setShowTestAccounts(!showTestAccounts)}
                    >
                        <MaterialCommunityIcons name="account-group" size={20} color={theme.colors.primary} />
                        <Text style={styles.testAccountsTitle}>Test Accounts</Text>
                        <MaterialCommunityIcons
                            name={showTestAccounts ? 'chevron-up' : 'chevron-down'}
                            size={20}
                            color={theme.colors.primary}
                        />
                    </TouchableOpacity>

                    {showTestAccounts && (
                        <View style={styles.testAccountsList}>
                            {TEST_ACCOUNTS.map((account) => (
                                <TouchableOpacity
                                    key={account.id}
                                    style={styles.testAccountCard}
                                    onPress={() => handleQuickLogin(account)}
                                    activeOpacity={0.7}
                                >
                                    <LinearGradient
                                        colors={
                                            account.id === 'USR001' ? ['#6366F1', '#8B5CF6'] :
                                                account.id === 'USR002' ? ['#F59E0B', '#D97706'] :
                                                    ['#10B981', '#059669']
                                        }
                                        style={styles.testAccountAvatar}
                                    >
                                        <Text style={styles.testAccountInitials}>
                                            {account.name.split(' ').map(n => n[0]).join('')}
                                        </Text>
                                    </LinearGradient>
                                    <View style={styles.testAccountInfo}>
                                        <Text style={styles.testAccountName}>{account.name}</Text>
                                        <Text style={styles.testAccountDesc} numberOfLines={1}>{account.description}</Text>
                                        <View style={styles.credentialRow}>
                                            <Text style={styles.credentialText}>
                                                <Text style={styles.credentialLabel}>Pass: </Text>
                                                {account.password}
                                            </Text>
                                        </View>
                                    </View>
                                    <MaterialCommunityIcons name="login" size={22} color={theme.colors.primary} />
                                </TouchableOpacity>
                            ))}
                        </View>
                    )}

                    {/* Trust Indicators */}
                    <View style={styles.trustRow}>
                        <View style={styles.trustItem}>
                            <MaterialCommunityIcons name="shield-check-outline" size={20} color={theme.colors.success} />
                            <Text style={styles.trustText}>Secure</Text>
                        </View>
                        <View style={styles.trustDivider} />
                        <View style={styles.trustItem}>
                            <MaterialCommunityIcons name="lock-outline" size={20} color={theme.colors.primary} />
                            <Text style={styles.trustText}>Encrypted</Text>
                        </View>
                        <View style={styles.trustDivider} />
                        <View style={styles.trustItem}>
                            <MaterialCommunityIcons name="account-group-outline" size={20} color={theme.colors.warning} />
                            <Text style={styles.trustText}>3 Test Users</Text>
                        </View>
                    </View>
                </KeyboardAvoidingView>
            </ScrollView>
        </SafeAreaView>
    );
}

LoginScreen.propTypes = {
    onLogin: PropTypes.func,
    onLoginWithUser: PropTypes.func,
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.colors.background,
    },
    scrollContent: {
        flexGrow: 1,
    },
    keyboardView: {
        flex: 1,
        justifyContent: 'center',
        paddingHorizontal: 24,
        paddingVertical: 24,
    },
    // Header
    header: {
        alignItems: 'center',
        marginBottom: 24,
    },
    logoBox: {
        marginBottom: 16,
    },
    logoGradient: {
        width: 80,
        height: 80,
        borderRadius: 24,
        alignItems: 'center',
        justifyContent: 'center',
        ...theme.shadows.card,
    },
    appName: {
        ...theme.typography.h1,
        color: theme.colors.textPrimary,
    },
    tagline: {
        ...theme.typography.body,
        color: theme.colors.textSecondary,
        marginTop: 4,
    },
    // Card
    card: {
        backgroundColor: theme.colors.surface,
        borderRadius: 24,
        padding: 24,
        ...theme.shadows.card,
    },
    cardTitle: {
        ...theme.typography.h2,
        color: theme.colors.textPrimary,
        textAlign: 'center',
    },
    cardSubtitle: {
        ...theme.typography.small,
        color: theme.colors.textSecondary,
        textAlign: 'center',
        marginTop: 4,
        marginBottom: 24,
    },
    // Inputs
    inputContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: theme.colors.surfaceAlt,
        borderRadius: 14,
        paddingHorizontal: 16,
        height: 56,
        marginBottom: 14,
        borderWidth: 1.5,
        borderColor: theme.colors.border,
    },
    inputFocused: {
        borderColor: theme.colors.primary,
        backgroundColor: theme.colors.surface,
    },
    input: {
        flex: 1,
        ...theme.typography.body,
        color: theme.colors.textPrimary,
        marginLeft: 12,
    },
    // Sign In Button
    signInButton: {
        borderRadius: 14,
        overflow: 'hidden',
        marginTop: 8,
        ...theme.shadows.soft,
    },
    signInGradient: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: 16,
        gap: 8,
    },
    signInText: {
        ...theme.typography.cta,
        color: 'white',
    },
    // Test Accounts
    testAccountsHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 24,
        gap: 8,
    },
    testAccountsTitle: {
        ...theme.typography.bodyMedium,
        color: theme.colors.primary,
    },
    testAccountsList: {
        marginTop: 12,
    },
    testAccountCard: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: theme.colors.surface,
        padding: 14,
        borderRadius: 16,
        marginBottom: 10,
        ...theme.shadows.soft,
    },
    testAccountAvatar: {
        width: 48,
        height: 48,
        borderRadius: 14,
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: 12,
    },
    testAccountInitials: {
        color: 'white',
        fontWeight: '700',
        fontSize: 16,
    },
    testAccountInfo: {
        flex: 1,
    },
    testAccountName: {
        ...theme.typography.bodyMedium,
        color: theme.colors.textPrimary,
    },
    testAccountDesc: {
        ...theme.typography.caption,
        color: theme.colors.textSecondary,
        marginTop: 2,
    },
    credentialRow: {
        marginTop: 4,
    },
    credentialText: {
        ...theme.typography.caption,
        color: theme.colors.textTertiary,
    },
    credentialLabel: {
        color: theme.colors.textSecondary,
        fontWeight: '600',
    },
    // Trust Row
    trustRow: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginTop: 24,
    },
    trustItem: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
    },
    trustText: {
        ...theme.typography.caption,
        color: theme.colors.textSecondary,
    },
    trustDivider: {
        width: 1,
        height: 18,
        backgroundColor: theme.colors.border,
        marginHorizontal: 16,
    },
});
