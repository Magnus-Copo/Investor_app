import React, { useState } from 'react';
import PropTypes from 'prop-types';
import {
    View,
    Text,
    ScrollView,
    StyleSheet,
    TouchableOpacity,
    StatusBar,
    Alert,
    Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { theme, formatCurrency } from '../../components/Theme';
import { MaterialCommunityIcons, MaterialIcons, Feather } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

import {
    portfolioSummary,
    investments,
    recentUpdates,
    getCurrentUser,
    getRelativeTime,
    pendingModifications,
    projects,
} from '../../data/mockData';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

/**
 * InvestorDashboard - Material Design 3 Inspired
 * Clean, intuitive, modern with proper iconography
 */
export default function InvestorDashboard({ navigation, onLogout }) {
    const currentUser = getCurrentUser(); // Get dynamic user
    const portfolio = portfolioSummary;
    const isPositive = portfolio.returns >= 0;
    const [activeTab, setActiveTab] = useState('investments');

    // Data
    const myCreatedProjects = projects.filter(p => p.createdBy === currentUser.id);
    const hasCreatedProjects = myCreatedProjects.length > 0;
    const myInvestments = investments;
    const pendingApprovals = pendingModifications.filter(m => !m.myVote || m.myVote === null);

    const handleProfilePress = () => {
        Alert.alert(
            "Account",
            null,
            [
                { text: "Profile", onPress: () => navigation.navigate('Profile') },
                { text: "Settings", onPress: () => navigation.navigate('Settings') },
                { text: "Sign Out", onPress: onLogout, style: "destructive" },
                { text: "Cancel", style: "cancel" }
            ]
        );
    };

    // Quick Actions with Material icons
    const quickActions = [
        {
            icon: 'check-circle-outline',
            iconType: 'material-community',
            label: 'Approvals',
            screen: 'Approvals',
            badge: pendingApprovals.length,
            bgColor: '#FEE2E2',
            iconColor: '#EF4444'
        },
        {
            icon: 'chart-line',
            iconType: 'material-community',
            label: 'Analytics',
            screen: 'PortfolioAnalytics',
            bgColor: '#EEF2FF',
            iconColor: '#6366F1'
        },
        {
            icon: 'file-document-outline',
            iconType: 'material-community',
            label: 'Reports',
            screen: 'Reports',
            bgColor: '#FEF3C7',
            iconColor: '#F59E0B'
        },
        {
            icon: 'plus-circle-outline',
            iconType: 'material-community',
            label: 'New',
            screen: 'CreateProjectInvestor',
            bgColor: '#D1FAE5',
            iconColor: '#10B981'
        },
    ];

    // Render icon based on type
    const renderIcon = (name, type, size, color) => {
        if (type === 'material-community') {
            return <MaterialCommunityIcons name={name} size={size} color={color} />;
        } else if (type === 'material') {
            return <MaterialIcons name={name} size={size} color={color} />;
        }
        return <Feather name={name} size={size} color={color} />;
    };

    // Investment item - Material Design card
    const renderInvestmentItem = (investment) => {
        const returnAmount = investment.currentValue - investment.invested;
        const isProfit = returnAmount >= 0;

        return (
            <TouchableOpacity
                key={investment.id}
                style={styles.card}
                onPress={() => navigation.navigate('ManageProjectInvestors', { projectId: investment.projectId })}
                activeOpacity={0.7}
            >
                <View style={styles.cardRow}>
                    <View style={[styles.iconBox, { backgroundColor: investment.type === 'Real Estate' ? '#EEF2FF' : '#D1FAE5' }]}>
                        <MaterialCommunityIcons
                            name={investment.type === 'Real Estate' ? 'office-building' : 'rocket-launch'}
                            size={22}
                            color={investment.type === 'Real Estate' ? '#6366F1' : '#10B981'}
                        />
                    </View>
                    <View style={styles.cardContent}>
                        <Text style={styles.cardTitle} numberOfLines={1}>{investment.name}</Text>
                        <View style={styles.cardMeta}>
                            <MaterialCommunityIcons name="tag-outline" size={12} color={theme.colors.textTertiary} />
                            <Text style={styles.cardSubtitle} numberOfLines={1}>{investment.type}</Text>
                        </View>
                    </View>
                    <View style={styles.cardValues}>
                        <Text style={styles.cardAmount} numberOfLines={1}>
                            {formatCurrency(investment.currentValue)}
                        </Text>
                        <View style={[styles.returnPill, isProfit ? styles.returnPillPositive : styles.returnPillNegative]}>
                            <MaterialCommunityIcons
                                name={isProfit ? "trending-up" : "trending-down"}
                                size={12}
                                color={isProfit ? '#10B981' : '#EF4444'}
                            />
                            <Text style={[styles.returnText, isProfit ? styles.returnTextPositive : styles.returnTextNegative]}>
                                {isProfit ? '+' : ''}{investment.returnsPercent}%
                            </Text>
                        </View>
                    </View>
                </View>
                {/* Progress bar */}
                <View style={styles.progressSection}>
                    <View style={styles.progressRow}>
                        <Text style={styles.progressLabel}>Progress</Text>
                        <Text style={styles.progressValue}>{investment.progress}%</Text>
                    </View>
                    <View style={styles.progressTrack}>
                        <LinearGradient
                            colors={['#6366F1', '#8B5CF6']}
                            start={{ x: 0, y: 0 }}
                            end={{ x: 1, y: 0 }}
                            style={[styles.progressFill, { width: `${investment.progress}%` }]}
                        />
                    </View>
                </View>
            </TouchableOpacity>
        );
    };

    // Project item
    const renderProjectItem = (project) => {
        const investorCount = project.projectInvestors?.length || 0;

        return (
            <TouchableOpacity
                key={project.id}
                style={styles.card}
                onPress={() => navigation.navigate('ManageProjectInvestors', { projectId: project.id })}
                activeOpacity={0.7}
            >
                <View style={styles.cardRow}>
                    <View style={[styles.iconBox, { backgroundColor: '#FEF3C7' }]}>
                        <MaterialCommunityIcons name="briefcase-outline" size={22} color="#F59E0B" />
                    </View>
                    <View style={styles.cardContent}>
                        <Text style={styles.cardTitle} numberOfLines={1}>{project.name}</Text>
                        <View style={styles.cardMeta}>
                            <MaterialCommunityIcons name="account-group-outline" size={12} color={theme.colors.textTertiary} />
                            <Text style={styles.cardSubtitle} numberOfLines={1}>{investorCount} investors</Text>
                        </View>
                    </View>
                    <View style={styles.adminChip}>
                        <MaterialCommunityIcons name="shield-check" size={14} color="#F59E0B" />
                        <Text style={styles.adminChipText}>Admin</Text>
                    </View>
                </View>
            </TouchableOpacity>
        );
    };

    return (
        <SafeAreaView style={styles.container} edges={['top']}>
            <StatusBar barStyle="dark-content" backgroundColor={theme.colors.background} />

            {/* Header - Material Design App Bar */}
            <View style={styles.appBar}>
                <View style={styles.appBarContent}>
                    <Text style={styles.greeting}>Welcome back</Text>
                    <Text style={styles.userName} numberOfLines={1}>{currentUser.name}</Text>
                </View>
                <View style={styles.appBarActions}>
                    <TouchableOpacity style={styles.iconButton}>
                        <MaterialCommunityIcons name="bell-outline" size={24} color={theme.colors.textPrimary} />
                        {recentUpdates.some(u => !u.read) && <View style={styles.notifDot} />}
                    </TouchableOpacity>
                    <TouchableOpacity onPress={handleProfilePress} style={styles.avatarButton}>
                        <LinearGradient colors={['#6366F1', '#8B5CF6']} style={styles.avatar}>
                            <Text style={styles.avatarText}>
                                {currentUser.name.split(' ').map(n => n[0]).join('')}
                            </Text>
                        </LinearGradient>
                    </TouchableOpacity>
                </View>
            </View>

            <ScrollView
                style={styles.scrollView}
                contentContainerStyle={styles.scrollContent}
                showsVerticalScrollIndicator={false}
            >
                {/* Portfolio Summary Card - Material Elevated */}
                <View style={styles.summaryCard}>
                    <View style={styles.summaryHeader}>
                        <View style={styles.summaryLabelRow}>
                            <MaterialCommunityIcons name="wallet-outline" size={18} color={theme.colors.textSecondary} />
                            <Text style={styles.summaryLabel}>Total Portfolio</Text>
                        </View>
                        <View style={[styles.trendBadge, isPositive ? styles.trendPositive : styles.trendNegative]}>
                            <MaterialCommunityIcons
                                name={isPositive ? "arrow-top-right" : "arrow-bottom-right"}
                                size={16}
                                color={isPositive ? '#10B981' : '#EF4444'}
                            />
                            <Text style={[styles.trendText, isPositive ? { color: '#10B981' } : { color: '#EF4444' }]}>
                                {isPositive ? '+' : ''}{portfolio.returnsPercent}%
                            </Text>
                        </View>
                    </View>
                    <Text style={styles.summaryAmount}>{formatCurrency(portfolio.currentValue)}</Text>

                    {/* Stats Row */}
                    <View style={styles.statsRow}>
                        <View style={styles.statBox}>
                            <View style={styles.statIconBox}>
                                <MaterialCommunityIcons name="arrow-down-circle-outline" size={20} color={theme.colors.textSecondary} />
                            </View>
                            <View>
                                <Text style={styles.statLabel}>Invested</Text>
                                <Text style={styles.statValue} numberOfLines={1}>{formatCurrency(portfolio.totalInvested)}</Text>
                            </View>
                        </View>
                        <View style={styles.statDivider} />
                        <View style={styles.statBox}>
                            <View style={[styles.statIconBox, isPositive ? styles.statIconPositive : styles.statIconNegative]}>
                                <MaterialCommunityIcons
                                    name={isPositive ? "arrow-up-circle-outline" : "arrow-down-circle-outline"}
                                    size={20}
                                    color={isPositive ? '#10B981' : '#EF4444'}
                                />
                            </View>
                            <View>
                                <Text style={styles.statLabel}>Returns</Text>
                                <Text style={[styles.statValue, isPositive ? styles.valuePositive : styles.valueNegative]} numberOfLines={1}>
                                    {formatCurrency(portfolio.returns, true)}
                                </Text>
                            </View>
                        </View>
                    </View>
                </View>

                {/* Quick Actions - Material Icon Grid */}
                <View style={styles.actionsSection}>
                    <Text style={styles.sectionLabel}>Quick Actions</Text>
                    <View style={styles.actionsGrid}>
                        {quickActions.map((action) => (
                            <TouchableOpacity
                                key={action.label}
                                style={styles.actionItem}
                                onPress={() => navigation.navigate(action.screen)}
                                activeOpacity={0.7}
                            >
                                <View style={[styles.actionIcon, { backgroundColor: action.bgColor }]}>
                                    {renderIcon(action.icon, action.iconType, 26, action.iconColor)}
                                    {action.badge > 0 && (
                                        <View style={styles.actionBadge}>
                                            <Text style={styles.actionBadgeText}>{action.badge > 9 ? '9+' : action.badge}</Text>
                                        </View>
                                    )}
                                </View>
                                <Text style={styles.actionLabel} numberOfLines={1}>{action.label}</Text>
                            </TouchableOpacity>
                        ))}
                    </View>
                </View>

                {/* Pending Approvals Alert */}
                {pendingApprovals.length > 0 && (
                    <TouchableOpacity
                        style={styles.alertBanner}
                        onPress={() => navigation.navigate('Approvals')}
                        activeOpacity={0.8}
                    >
                        <View style={styles.alertIconBox}>
                            <MaterialCommunityIcons name="alert-circle" size={22} color="#F59E0B" />
                        </View>
                        <View style={styles.alertContent}>
                            <Text style={styles.alertTitle} numberOfLines={1}>
                                {pendingApprovals.length} approval{pendingApprovals.length > 1 ? 's' : ''} needed
                            </Text>
                            <Text style={styles.alertSubtitle} numberOfLines={1}>Tap to review and vote</Text>
                        </View>
                        <MaterialCommunityIcons name="chevron-right" size={24} color={theme.colors.textTertiary} />
                    </TouchableOpacity>
                )}

                {/* Segmented Control - Material Chip Group */}
                <View style={styles.chipGroup}>
                    <TouchableOpacity
                        style={[styles.chip, activeTab === 'investments' && styles.chipActive]}
                        onPress={() => setActiveTab('investments')}
                    >
                        <MaterialCommunityIcons
                            name="layers-outline"
                            size={18}
                            color={activeTab === 'investments' ? '#6366F1' : theme.colors.textSecondary}
                        />
                        <Text style={[styles.chipText, activeTab === 'investments' && styles.chipTextActive]}>
                            Investments
                        </Text>
                        <View style={styles.chipCount}>
                            <Text style={styles.chipCountText}>{myInvestments.length}</Text>
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={[styles.chip, activeTab === 'projects' && styles.chipActive]}
                        onPress={() => setActiveTab('projects')}
                    >
                        <MaterialCommunityIcons
                            name="briefcase-outline"
                            size={18}
                            color={activeTab === 'projects' ? '#6366F1' : theme.colors.textSecondary}
                        />
                        <Text style={[styles.chipText, activeTab === 'projects' && styles.chipTextActive]}>
                            Projects
                        </Text>
                        {hasCreatedProjects && (
                            <View style={[styles.chipCount, { backgroundColor: '#FEF3C7' }]}>
                                <Text style={[styles.chipCountText, { color: '#F59E0B' }]}>{myCreatedProjects.length}</Text>
                            </View>
                        )}
                    </TouchableOpacity>
                </View>

                {/* Content List */}
                <View style={styles.listSection}>
                    {activeTab === 'investments' ? (
                        myInvestments.length > 0 ? (
                            myInvestments.map(renderInvestmentItem)
                        ) : (
                            <View style={styles.emptyState}>
                                <MaterialCommunityIcons name="wallet-outline" size={56} color={theme.colors.textTertiary} />
                                <Text style={styles.emptyTitle}>No investments yet</Text>
                                <Text style={styles.emptySubtitle}>Start building your portfolio</Text>
                            </View>
                        )
                    ) : (
                        hasCreatedProjects ? (
                            myCreatedProjects.map(renderProjectItem)
                        ) : (
                            <View style={styles.emptyState}>
                                <MaterialCommunityIcons name="briefcase-plus-outline" size={56} color={theme.colors.textTertiary} />
                                <Text style={styles.emptyTitle}>No projects created</Text>
                                <Text style={styles.emptySubtitle}>Create a project to get started</Text>
                                <TouchableOpacity
                                    style={styles.emptyButton}
                                    onPress={() => navigation.navigate('CreateProjectInvestor')}
                                >
                                    <MaterialCommunityIcons name="plus" size={18} color="white" />
                                    <Text style={styles.emptyButtonText}>Create Project</Text>
                                </TouchableOpacity>
                            </View>
                        )
                    )}
                </View>

                {/* Recent Activity */}
                {recentUpdates.length > 0 && (
                    <View style={styles.activitySection}>
                        <Text style={styles.sectionTitle}>Recent Activity</Text>
                        {recentUpdates.slice(0, 3).map((update) => (
                            <View key={update.id} style={styles.activityItem}>
                                <View style={[styles.activityDot, !update.read && styles.activityDotUnread]} />
                                <View style={styles.activityContent}>
                                    <Text style={styles.activityTitle} numberOfLines={1}>{update.title}</Text>
                                    <Text style={styles.activityMeta} numberOfLines={1}>
                                        {update.project} • {getRelativeTime(update.timestamp)}
                                    </Text>
                                </View>
                            </View>
                        ))}
                    </View>
                )}

                <View style={{ height: 100 }} />
            </ScrollView>

            {/* FAB - Material Design */}
            <TouchableOpacity
                style={styles.fab}
                onPress={() => navigation.navigate('CreateProjectInvestor')}
                activeOpacity={0.9}
            >
                <LinearGradient colors={['#10B981', '#059669']} style={styles.fabGradient}>
                    <MaterialCommunityIcons name="plus" size={28} color="white" />
                </LinearGradient>
            </TouchableOpacity>
        </SafeAreaView>
    );
}

InvestorDashboard.propTypes = {
    navigation: PropTypes.shape({ navigate: PropTypes.func }),
    onLogout: PropTypes.func,
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.colors.background,
    },
    // App Bar
    appBar: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingHorizontal: 20,
        paddingVertical: 12,
    },
    appBarContent: {},
    greeting: {
        ...theme.typography.caption,
        color: theme.colors.textSecondary,
        textTransform: 'uppercase',
        letterSpacing: 0.5,
    },
    userName: {
        ...theme.typography.h2,
        color: theme.colors.textPrimary,
        marginTop: 2,
        maxWidth: SCREEN_WIDTH * 0.6,
    },
    appBarActions: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
    },
    iconButton: {
        width: 44,
        height: 44,
        borderRadius: 22,
        backgroundColor: theme.colors.surfaceAlt,
        alignItems: 'center',
        justifyContent: 'center',
    },
    notifDot: {
        position: 'absolute',
        top: 10,
        right: 10,
        width: 10,
        height: 10,
        borderRadius: 5,
        backgroundColor: theme.colors.danger,
        borderWidth: 2,
        borderColor: theme.colors.surfaceAlt,
    },
    avatarButton: {
        borderRadius: 22,
    },
    avatar: {
        width: 44,
        height: 44,
        borderRadius: 22,
        alignItems: 'center',
        justifyContent: 'center',
    },
    avatarText: {
        color: 'white',
        fontWeight: '700',
        fontSize: 15,
    },
    scrollView: {
        flex: 1,
    },
    scrollContent: {
        paddingBottom: 24,
    },
    // Summary Card
    summaryCard: {
        marginHorizontal: 20,
        backgroundColor: theme.colors.surface,
        borderRadius: 20,
        padding: 20,
        ...theme.shadows.card,
    },
    summaryHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 8,
    },
    summaryLabelRow: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 6,
    },
    summaryLabel: {
        ...theme.typography.caption,
        color: theme.colors.textSecondary,
        textTransform: 'uppercase',
        letterSpacing: 0.5,
    },
    trendBadge: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 10,
        paddingVertical: 4,
        borderRadius: 20,
        gap: 4,
    },
    trendPositive: {
        backgroundColor: '#D1FAE5',
    },
    trendNegative: {
        backgroundColor: '#FEE2E2',
    },
    trendText: {
        ...theme.typography.captionBold,
    },
    summaryAmount: {
        ...theme.typography.hero,
        color: theme.colors.textPrimary,
        marginBottom: 16,
    },
    statsRow: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: theme.colors.surfaceAlt,
        borderRadius: 14,
        padding: 14,
    },
    statBox: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
    },
    statIconBox: {
        width: 36,
        height: 36,
        borderRadius: 10,
        backgroundColor: theme.colors.surface,
        alignItems: 'center',
        justifyContent: 'center',
    },
    statIconPositive: {
        backgroundColor: '#D1FAE5',
    },
    statIconNegative: {
        backgroundColor: '#FEE2E2',
    },
    statLabel: {
        ...theme.typography.caption,
        color: theme.colors.textSecondary,
    },
    statValue: {
        ...theme.typography.bodyMedium,
        color: theme.colors.textPrimary,
        marginTop: 2,
    },
    valuePositive: {
        color: '#10B981',
    },
    valueNegative: {
        color: '#EF4444',
    },
    statDivider: {
        width: 1,
        height: 32,
        backgroundColor: theme.colors.border,
        marginHorizontal: 14,
    },
    // Actions Section
    actionsSection: {
        marginTop: 24,
        paddingHorizontal: 20,
    },
    sectionLabel: {
        ...theme.typography.caption,
        color: theme.colors.textSecondary,
        textTransform: 'uppercase',
        letterSpacing: 0.5,
        marginBottom: 12,
    },
    actionsGrid: {
        flexDirection: 'row',
        gap: 12,
    },
    actionItem: {
        flex: 1,
        alignItems: 'center',
    },
    actionIcon: {
        width: 60,
        height: 60,
        borderRadius: 16,
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 8,
    },
    actionBadge: {
        position: 'absolute',
        top: -4,
        right: -4,
        backgroundColor: '#EF4444',
        width: 20,
        height: 20,
        borderRadius: 10,
        alignItems: 'center',
        justifyContent: 'center',
        borderWidth: 2,
        borderColor: theme.colors.background,
    },
    actionBadgeText: {
        color: 'white',
        fontSize: 10,
        fontWeight: '700',
    },
    actionLabel: {
        ...theme.typography.caption,
        color: theme.colors.textSecondary,
    },
    // Alert Banner
    alertBanner: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#FFFBEB',
        marginHorizontal: 20,
        marginTop: 20,
        padding: 14,
        borderRadius: 14,
        borderWidth: 1,
        borderColor: '#FDE68A',
    },
    alertIconBox: {
        marginRight: 12,
    },
    alertContent: {
        flex: 1,
    },
    alertTitle: {
        ...theme.typography.bodyMedium,
        color: theme.colors.textPrimary,
    },
    alertSubtitle: {
        ...theme.typography.caption,
        color: theme.colors.textSecondary,
        marginTop: 2,
    },
    // Chip Group
    chipGroup: {
        flexDirection: 'row',
        marginHorizontal: 20,
        marginTop: 24,
        gap: 10,
    },
    chip: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: theme.colors.surface,
        paddingVertical: 12,
        paddingHorizontal: 14,
        borderRadius: 12,
        gap: 6,
        borderWidth: 1,
        borderColor: theme.colors.border,
    },
    chipActive: {
        backgroundColor: '#EEF2FF',
        borderColor: '#6366F1',
    },
    chipText: {
        ...theme.typography.smallMedium,
        color: theme.colors.textSecondary,
    },
    chipTextActive: {
        color: '#6366F1',
    },
    chipCount: {
        backgroundColor: theme.colors.primaryLight,
        paddingHorizontal: 6,
        paddingVertical: 2,
        borderRadius: 6,
    },
    chipCountText: {
        fontSize: 11,
        fontWeight: '600',
        color: theme.colors.primary,
    },
    // List Section
    listSection: {
        marginTop: 16,
        paddingHorizontal: 20,
    },
    // Cards
    card: {
        backgroundColor: theme.colors.surface,
        borderRadius: 16,
        padding: 16,
        marginBottom: 12,
        ...theme.shadows.soft,
    },
    cardRow: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    iconBox: {
        width: 48,
        height: 48,
        borderRadius: 14,
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: 14,
    },
    cardContent: {
        flex: 1,
        marginRight: 12,
    },
    cardTitle: {
        ...theme.typography.bodyMedium,
        color: theme.colors.textPrimary,
        marginBottom: 4,
    },
    cardMeta: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 4,
    },
    cardSubtitle: {
        ...theme.typography.caption,
        color: theme.colors.textSecondary,
    },
    cardValues: {
        alignItems: 'flex-end',
    },
    cardAmount: {
        ...theme.typography.bodySemibold,
        color: theme.colors.textPrimary,
    },
    returnPill: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 8,
        paddingVertical: 3,
        borderRadius: 12,
        marginTop: 4,
        gap: 3,
    },
    returnPillPositive: {
        backgroundColor: '#D1FAE5',
    },
    returnPillNegative: {
        backgroundColor: '#FEE2E2',
    },
    returnText: {
        fontSize: 11,
        fontWeight: '600',
    },
    returnTextPositive: {
        color: '#10B981',
    },
    returnTextNegative: {
        color: '#EF4444',
    },
    // Progress
    progressSection: {
        marginTop: 14,
        paddingTop: 14,
        borderTopWidth: 1,
        borderTopColor: theme.colors.borderLight,
    },
    progressRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 8,
    },
    progressLabel: {
        ...theme.typography.caption,
        color: theme.colors.textSecondary,
    },
    progressValue: {
        ...theme.typography.captionBold,
        color: theme.colors.primary,
    },
    progressTrack: {
        height: 6,
        backgroundColor: theme.colors.surfaceAlt,
        borderRadius: 3,
        overflow: 'hidden',
    },
    progressFill: {
        height: '100%',
        borderRadius: 3,
    },
    // Admin Chip
    adminChip: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#FEF3C7',
        paddingHorizontal: 10,
        paddingVertical: 5,
        borderRadius: 8,
        gap: 4,
    },
    adminChipText: {
        ...theme.typography.caption,
        color: '#F59E0B',
        fontWeight: '600',
    },
    // Empty State
    emptyState: {
        alignItems: 'center',
        paddingVertical: 48,
    },
    emptyTitle: {
        ...theme.typography.bodyMedium,
        color: theme.colors.textSecondary,
        marginTop: 16,
    },
    emptySubtitle: {
        ...theme.typography.caption,
        color: theme.colors.textTertiary,
        marginTop: 4,
    },
    emptyButton: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: theme.colors.primary,
        paddingHorizontal: 20,
        paddingVertical: 12,
        borderRadius: 12,
        marginTop: 20,
        gap: 6,
    },
    emptyButtonText: {
        ...theme.typography.cta,
        color: 'white',
    },
    // Activity Section
    activitySection: {
        marginTop: 24,
        paddingHorizontal: 20,
    },
    sectionTitle: {
        ...theme.typography.h4,
        color: theme.colors.textPrimary,
        marginBottom: 12,
    },
    activityItem: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        paddingVertical: 12,
        borderBottomWidth: 1,
        borderBottomColor: theme.colors.borderLight,
    },
    activityDot: {
        width: 8,
        height: 8,
        borderRadius: 4,
        backgroundColor: theme.colors.border,
        marginTop: 6,
        marginRight: 12,
    },
    activityDotUnread: {
        backgroundColor: theme.colors.primary,
    },
    activityContent: {
        flex: 1,
    },
    activityTitle: {
        ...theme.typography.small,
        color: theme.colors.textPrimary,
    },
    activityMeta: {
        ...theme.typography.caption,
        color: theme.colors.textTertiary,
        marginTop: 2,
    },
    // FAB
    fab: {
        position: 'absolute',
        bottom: 24,
        right: 20,
        borderRadius: 28,
        overflow: 'hidden',
        ...theme.shadows.card,
    },
    fabGradient: {
        width: 56,
        height: 56,
        borderRadius: 28,
        alignItems: 'center',
        justifyContent: 'center',
    },
});
