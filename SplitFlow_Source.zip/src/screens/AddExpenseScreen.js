import React, { useState } from 'react';
import PropTypes from 'prop-types';
import {
    View,
    Text,
    TextInput,
    StyleSheet,
    TouchableOpacity,
    Platform
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { theme } from '../components/Theme';
import { Ionicons } from '@expo/vector-icons';

export default function AddExpenseScreen({ navigation }) {
    const [amount, setAmount] = useState('');

    return (
        <SafeAreaView style={styles.container} edges={['bottom', 'left', 'right']}>
            <View style={styles.content}>
                {/* Header */}
                <View style={styles.header}>
                    <TouchableOpacity onPress={() => navigation.goBack()} style={styles.closeBtn}>
                        <Ionicons name="close" size={24} color={theme.colors.textSecondary} />
                    </TouchableOpacity>
                    <Text style={styles.headerTitle}>Add Expense</Text>
                    <View style={{ width: 40 }} />
                </View>

                {/* Amount Input */}
                <View style={styles.amountContainer}>
                    <Text style={styles.currencySymbol}>₹</Text>
                    <TextInput
                        style={styles.amountInput}
                        value={amount}
                        onChangeText={setAmount}
                        placeholder="0"
                        placeholderTextColor={theme.colors.textSecondary}
                        keyboardType="numeric"
                        autoFocus
                    />
                </View>

                {/* Description */}
                <View style={styles.inputContainer}>
                    <TextInput
                        style={styles.descriptionInput}
                        placeholder="What's this for?"
                        placeholderTextColor={theme.colors.textSecondary}
                    />
                </View>

                {/* Split With */}
                <View style={styles.section}>
                    <Text style={styles.sectionLabel}>Split with</Text>
                    <View style={styles.chipContainer}>
                        {['Roommates', 'Trip to Goa', 'Partner', 'Office'].map((chip) => (
                            <TouchableOpacity
                                key={chip}
                                style={[styles.chip, chip === 'Roommates' && styles.chipActive]}
                            >
                                <Text style={[styles.chipText, chip === 'Roommates' && styles.chipTextActive]}>{chip}</Text>
                            </TouchableOpacity>
                        ))}
                    </View>
                </View>

                {/* Save Button */}
                <View style={styles.footer}>
                    <TouchableOpacity
                        style={styles.saveBtn}
                        onPress={() => navigation.goBack()}
                    >
                        <Ionicons name="checkmark" size={24} color="white" />
                        <Text style={styles.saveBtnText}>Save Expense</Text>
                    </TouchableOpacity>
                </View>
            </View>
        </SafeAreaView>
    );
}

AddExpenseScreen.propTypes = {
    navigation: PropTypes.shape({
        goBack: PropTypes.func,
    }),
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.colors.background,
        paddingTop: Platform.OS === 'android' ? 24 : 0,
    },
    content: {
        flex: 1,
        padding: theme.spacing.l,
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: theme.spacing.xl,
    },
    closeBtn: {
        padding: theme.spacing.s,
    },
    headerTitle: {
        fontSize: 18,
        fontWeight: '600',
        color: theme.colors.textPrimary,
    },
    amountContainer: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: theme.spacing.xl,
    },
    currencySymbol: {
        fontSize: 32,
        fontWeight: '700',
        color: theme.colors.textSecondary,
        marginRight: 8,
    },
    amountInput: {
        fontSize: 56,
        fontWeight: '700',
        color: theme.colors.textPrimary,
        minWidth: 60,
        textAlign: 'center',
    },
    inputContainer: {
        marginBottom: theme.spacing.xl,
    },
    descriptionInput: {
        backgroundColor: theme.colors.surface,
        padding: theme.spacing.l,
        borderRadius: theme.borderRadius.l,
        fontSize: 18,
        color: theme.colors.textPrimary,
        borderWidth: 1,
        borderColor: theme.colors.border,
    },
    section: {
        marginBottom: theme.spacing.xl,
    },
    sectionLabel: {
        fontSize: 14,
        color: theme.colors.textSecondary,
        marginBottom: theme.spacing.m,
    },
    chipContainer: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        gap: theme.spacing.s,
    },
    chip: {
        paddingVertical: 8,
        paddingHorizontal: 16,
        borderRadius: theme.borderRadius.full,
        borderWidth: 1,
        borderColor: theme.colors.border,
        backgroundColor: theme.colors.surface,
    },
    chipActive: {
        backgroundColor: theme.colors.primary,
        borderColor: theme.colors.primary,
    },
    chipText: {
        fontSize: 14,
        color: theme.colors.textSecondary,
        fontWeight: '500',
    },
    chipTextActive: {
        color: 'white',
    },
    footer: {
        marginTop: 'auto',
    },
    saveBtn: {
        backgroundColor: theme.colors.primary,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        padding: theme.spacing.l,
        borderRadius: theme.borderRadius.xl,
        gap: theme.spacing.s,
        ...theme.shadows.glow,
    },
    saveBtnText: {
        color: 'white',
        fontSize: 18,
        fontWeight: '600',
    },
});
