// InvestFlow Theme - Premium Design System
// Royal, Elegant, Professional Investment Platform

export const theme = {
    colors: {
        // Premium Primary - Deep Royal Purple/Violet
        primary: '#6366F1',        // Vibrant Indigo
        primaryLight: '#EEF2FF',   // Soft Indigo Tint
        primaryDark: '#4338CA',    // Deep Indigo
        primaryGradient: ['#667eea', '#764ba2'],

        // Accent - Luxury Gold/Amber
        accent: '#F59E0B',         // Warm Gold
        accentLight: '#FEF3C7',    // Soft Gold Tint        
        accentDark: '#D97706',     // Deep Gold

        // Secondary - Premium Teal
        secondary: '#14B8A6',      // Teal 500 - Growth, Prosperity
        secondaryLight: '#CCFBF1', // Teal 100
        secondaryGradient: ['#10B981', '#14B8A6'],

        // Background Colors - Clean & Elegant
        background: '#F8FAFC',     // Pure Light Gray
        surface: '#FFFFFF',        // Clean White
        surfaceAlt: '#F1F5F9',     // Subtle Gray
        surfaceElevated: '#FFFFFF',

        // Text Colors - Rich Contrast
        textPrimary: '#0F172A',    // Deep Slate - Maximum readability
        textSecondary: '#475569',  // Balanced Gray
        textTertiary: '#94A3B8',   // Subtle Gray
        textLight: '#FFFFFF',
        textMuted: '#CBD5E1',

        // Semantic Colors - Refined
        success: '#10B981',        // Emerald - Profit, Growth
        successLight: '#D1FAE5',   // Soft Emerald
        successGradient: ['#10B981', '#059669'],

        warning: '#F59E0B',        // Amber - Attention
        warningLight: '#FEF3C7',   // Soft Amber

        danger: '#EF4444',         // Red - Alert, Loss
        dangerLight: '#FEE2E2',    // Soft Red
        dangerGradient: ['#EF4444', '#DC2626'],

        info: '#3B82F6',           // Blue - Information
        infoLight: '#DBEAFE',      // Soft Blue

        // Border Colors - Refined
        border: '#E2E8F0',         // Subtle Border
        borderLight: '#F1F5F9',    // Very Light Border
        borderFocus: '#6366F1',    // Focus State

        // Premium Card Colors
        cardGradientStart: 'rgba(99, 102, 241, 0.08)',
        cardGradientEnd: 'rgba(139, 92, 246, 0.04)',

        // Chart Colors - Harmonious
        chart: {
            profit: '#10B981',
            loss: '#EF4444',
            neutral: '#64748B',
            line1: '#6366F1',
            line2: '#14B8A6',
            line3: '#F59E0B',
            area: 'rgba(99, 102, 241, 0.15)',
        },

        // Glassmorphism
        glass: 'rgba(255, 255, 255, 0.85)',
        glassLight: 'rgba(255, 255, 255, 0.6)',
        glassDark: 'rgba(15, 23, 42, 0.8)',
    },

    // Premium Gradients
    gradients: {
        primary: ['#667eea', '#764ba2'],
        primaryVertical: ['#6366F1', '#4F46E5'],
        success: ['#10B981', '#059669'],
        royal: ['#1e3a8a', '#3730a3', '#4c1d95'],
        gold: ['#f59e0b', '#d97706'],
        sunset: ['#f43f5e', '#ec4899'],
        ocean: ['#0ea5e9', '#06b6d4'],
        dark: ['#1e293b', '#0f172a'],
    },

    spacing: {
        xs: 4,
        s: 8,
        m: 16,
        l: 24,
        xl: 32,
        xxl: 48,
    },

    borderRadius: {
        xs: 6,
        s: 10,
        m: 14,
        l: 18,
        xl: 24,
        xxl: 32,
        full: 9999,
    },

    // Neuromarketing Typography System
    // Based on emotional impact, visual hierarchy, and trust-building principles
    typography: {
        // Hero - Maximum Emotional Impact (Portfolio Value, Key Numbers)
        hero: { fontSize: 42, fontWeight: '800', lineHeight: 48, letterSpacing: -1.5 },
        heroMedium: { fontSize: 36, fontWeight: '700', lineHeight: 42, letterSpacing: -1 },

        // Headers - Authority & Trust (Premium Weights for confidence)
        h1: { fontSize: 28, fontWeight: '700', lineHeight: 36, letterSpacing: -0.5 },
        h2: { fontSize: 22, fontWeight: '700', lineHeight: 30, letterSpacing: -0.3 },
        h3: { fontSize: 18, fontWeight: '600', lineHeight: 26, letterSpacing: -0.2 },
        h4: { fontSize: 16, fontWeight: '600', lineHeight: 22 },

        // Body - Optimal Readability (14-16px per neuromarketing research)
        body: { fontSize: 15, fontWeight: '400', lineHeight: 22 },
        bodyMedium: { fontSize: 15, fontWeight: '500', lineHeight: 22 },
        bodySemibold: { fontSize: 15, fontWeight: '600', lineHeight: 22 },

        // Small - Supporting Info (Clear but not dominant)
        small: { fontSize: 13, fontWeight: '400', lineHeight: 18 },
        smallMedium: { fontSize: 13, fontWeight: '500', lineHeight: 18 },
        smallSemibold: { fontSize: 13, fontWeight: '600', lineHeight: 18 },

        // Caption - Subtle Context (Labels, timestamps)
        caption: { fontSize: 11, fontWeight: '500', lineHeight: 14, letterSpacing: 0.3 },
        captionMedium: { fontSize: 11, fontWeight: '600', lineHeight: 14, letterSpacing: 0.3 },
        captionBold: { fontSize: 11, fontWeight: '700', lineHeight: 14, letterSpacing: 0.5 },

        // Money/Numbers - Trust & Impact (Tight letter spacing for professionalism)
        amount: { fontSize: 32, fontWeight: '700', lineHeight: 38, letterSpacing: -0.8 },
        amountLarge: { fontSize: 40, fontWeight: '800', lineHeight: 46, letterSpacing: -1.2 },
        amountSmall: { fontSize: 20, fontWeight: '600', lineHeight: 26, letterSpacing: -0.3 },

        // Labels - Scannability (Uppercase for quick recognition)
        label: { fontSize: 10, fontWeight: '600', lineHeight: 12, letterSpacing: 1, textTransform: 'uppercase' },
        labelLarge: { fontSize: 12, fontWeight: '600', lineHeight: 16, letterSpacing: 0.8, textTransform: 'uppercase' },

        // Urgency - Action-Oriented (Slightly bold for CTAs)
        cta: { fontSize: 15, fontWeight: '600', lineHeight: 20, letterSpacing: 0.2 },
        ctaLarge: { fontSize: 17, fontWeight: '700', lineHeight: 24, letterSpacing: 0.1 },

        // Friendly - Approachable (For onboarding, tips)
        friendly: { fontSize: 16, fontWeight: '500', lineHeight: 24, letterSpacing: 0.1 },
        friendlyLarge: { fontSize: 18, fontWeight: '600', lineHeight: 28, letterSpacing: 0 },
    },

    shadows: {
        none: {
            shadowColor: 'transparent',
            shadowOffset: { width: 0, height: 0 },
            shadowOpacity: 0,
            shadowRadius: 0,
            elevation: 0,
        },
        soft: {
            shadowColor: '#6366F1',
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.06,
            shadowRadius: 10,
            elevation: 2,
        },
        card: {
            shadowColor: '#1e293b',
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: 0.08,
            shadowRadius: 16,
            elevation: 4,
        },
        elevated: {
            shadowColor: '#1e293b',
            shadowOffset: { width: 0, height: 8 },
            shadowOpacity: 0.12,
            shadowRadius: 24,
            elevation: 6,
        },
        glow: {
            shadowColor: '#6366F1',
            shadowOffset: { width: 0, height: 8 },
            shadowOpacity: 0.35,
            shadowRadius: 20,
            elevation: 10,
        },
        successGlow: {
            shadowColor: '#10B981',
            shadowOffset: { width: 0, height: 6 },
            shadowOpacity: 0.35,
            shadowRadius: 16,
            elevation: 6,
        },
        dangerGlow: {
            shadowColor: '#EF4444',
            shadowOffset: { width: 0, height: 6 },
            shadowOpacity: 0.35,
            shadowRadius: 16,
            elevation: 6,
        },
        goldGlow: {
            shadowColor: '#F59E0B',
            shadowOffset: { width: 0, height: 6 },
            shadowOpacity: 0.35,
            shadowRadius: 16,
            elevation: 6,
        },
        premium: {
            shadowColor: '#4338CA',
            shadowOffset: { width: 0, height: 12 },
            shadowOpacity: 0.25,
            shadowRadius: 28,
            elevation: 12,
        },
    },
};

// Helper function to format currency in INR
export const formatCurrency = (amount, showSign = false) => {
    const absAmount = Math.abs(amount);
    let formatted;

    if (absAmount >= 10000000) {
        formatted = `₹${(absAmount / 10000000).toFixed(2)}Cr`;
    } else if (absAmount >= 100000) {
        formatted = `₹${(absAmount / 100000).toFixed(2)}L`;
    } else if (absAmount >= 1000) {
        formatted = `₹${(absAmount / 1000).toFixed(1)}K`;
    } else {
        formatted = `₹${absAmount.toLocaleString('en-IN')}`;
    }

    if (showSign && amount !== 0) {
        return amount > 0 ? `+${formatted}` : `-${formatted}`;
    }
    return formatted;
};

// Helper to get status color
export const getStatusColor = (status) => {
    switch (status?.toLowerCase()) {
        case 'active':
        case 'completed':
        case 'approved':
            return theme.colors.success;
        case 'pending':
        case 'in_progress':
            return theme.colors.warning;
        case 'delayed':
        case 'rejected':
        case 'overdue':
            return theme.colors.danger;
        default:
            return theme.colors.textSecondary;
    }
};

// Helper to get status background color
export const getStatusBgColor = (status) => {
    switch (status?.toLowerCase()) {
        case 'active':
        case 'completed':
        case 'approved':
            return theme.colors.successLight;
        case 'pending':
        case 'in_progress':
            return theme.colors.warningLight;
        case 'delayed':
        case 'rejected':
        case 'overdue':
            return theme.colors.dangerLight;
        default:
            return theme.colors.surfaceAlt;
    }
};
