import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';

// Context
import { AuthProvider } from './src/context/AuthContext';

// Screens
import LoginScreen from './src/screens/LoginScreen';
import OnboardingScreen from './src/screens/onboarding/OnboardingScreen';
import ReportsScreen from './src/screens/client/ReportsScreen';
import ApprovalsScreen from './src/screens/client/ApprovalsScreen';
import PortfolioAnalyticsScreen from './src/screens/client/PortfolioAnalyticsScreen';

// Investor Screens
import InvestorDashboard from './src/screens/investor/InvestorDashboard';
import CreateProjectInvestorScreen from './src/screens/investor/CreateProjectInvestorScreen';
import ManageProjectInvestorsScreen from './src/screens/investor/ManageProjectInvestorsScreen';
import ProjectApprovalDetailScreen from './src/screens/investor/ProjectApprovalDetailScreen';

// Shared Screens
import ProfileScreen from './src/screens/shared/ProfileScreen';
import SettingsScreen from './src/screens/shared/SettingsScreen';
import { setCurrentUserId as setGlobalUser } from './src/data/mockData';

const Stack = createNativeStackNavigator();

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [hasOnboarded, setHasOnboarded] = useState(false);
  const [currentUserId, setCurrentUserId] = useState('USR001');

  const handleLogin = (userId = 'USR001') => {
    setGlobalUser(userId); // Update global mock data state
    setCurrentUserId(userId);
    setIsLoggedIn(true);
  };
  const handleLogout = () => {
    setIsLoggedIn(false);
    setHasOnboarded(false);
  };
  const handleOnboardingComplete = () => setHasOnboarded(true);

  return (
    <AuthProvider>
      <SafeAreaProvider>
        <NavigationContainer>
          <StatusBar style="auto" />
          <Stack.Navigator
            screenOptions={{
              headerShown: false,
              animation: 'slide_from_right',
            }}
          >
            {!isLoggedIn ? (
              <Stack.Screen name="Login">
                {(props) => <LoginScreen {...props} onLogin={handleLogin} />}
              </Stack.Screen>
            ) : !hasOnboarded ? (
              <Stack.Screen name="Onboarding">
                {(props) => <OnboardingScreen {...props} onComplete={handleOnboardingComplete} />}
              </Stack.Screen>
            ) : (
              <>
                <Stack.Screen name="InvestorDashboard">
                  {(props) => <InvestorDashboard {...props} onLogout={handleLogout} />}
                </Stack.Screen>
                <Stack.Screen
                  name="Reports"
                  component={ReportsScreen}
                  options={{ animation: 'slide_from_bottom' }}
                />
                <Stack.Screen
                  name="Approvals"
                  component={ApprovalsScreen}
                  options={{ animation: 'slide_from_bottom' }}
                />
                <Stack.Screen
                  name="PortfolioAnalytics"
                  component={PortfolioAnalyticsScreen}
                  options={{ animation: 'slide_from_bottom' }}
                />
                <Stack.Screen
                  name="CreateProjectInvestor"
                  component={CreateProjectInvestorScreen}
                  options={{ animation: 'slide_from_bottom' }}
                />
                <Stack.Screen
                  name="ManageProjectInvestors"
                  component={ManageProjectInvestorsScreen}
                  options={{ animation: 'slide_from_bottom' }}
                />
                <Stack.Screen
                  name="ProjectApprovalDetail"
                  component={ProjectApprovalDetailScreen}
                  options={{ animation: 'slide_from_bottom' }}
                />
                <Stack.Screen name="Profile">
                  {(props) => <ProfileScreen {...props} onLogout={handleLogout} />}
                </Stack.Screen>
                <Stack.Screen
                  name="Settings"
                  component={SettingsScreen}
                  options={{ animation: 'slide_from_bottom' }}
                />
              </>
            )}
          </Stack.Navigator>
        </NavigationContainer>
      </SafeAreaProvider>
    </AuthProvider>
  );
}
